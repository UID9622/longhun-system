# 🐉 龙魂MCP服务器项目

**DNA追溯码**：#龙芯⚡️2026-02-21-MCP项目完整包-v1.0  
**确认码**：#CONFIRM🌌9622-ONLY-ONCE🧬LONGHUN-MCP-PKG-001

**作者**：Lucky (UID9622)  
**协作**：Claude (Anthropic)  
**完成时间**：2026年02月21日 06:18

---

## 📦 项目文件清单

```yaml
核心文件：
  ✅ longhun_mcp_server.py  - MCP服务器主程序（400+行）
  ✅ mcp_config.json         - Claude配置文件
  ✅ deploy_mcp.sh           - 一键部署脚本
  ✅ test_mcp.py             - 完整测试脚本
  ✅ MCP使用说明.md          - 详细使用文档
  ✅ README.md               - 本文件

服务器信息：
  - 地址：119.13.90.27
  - 端口：8080
  - 数据库：SQLite（华为云本地）
  - 日志：/home/longhun/logs/mcp_server.log
```

---

## 🚀 快速部署（3步搞定）

### 第1步：上传文件到服务器

```bash
# 本地操作（在你的电脑上）
scp longhun_mcp_server.py root@119.13.90.27:/root/
scp mcp_config.json root@119.13.90.27:/root/
scp deploy_mcp.sh root@119.13.90.27:/root/
scp test_mcp.py root@119.13.90.27:/root/
```

### 第2步：一键部署

```bash
# 连接到服务器
ssh root@119.13.90.27

# 运行部署脚本
cd /root
chmod +x deploy_mcp.sh
sudo bash deploy_mcp.sh
```

部署脚本会自动：
- ✅ 创建目录结构
- ✅ 安装Python依赖（flask, flask-cors）
- ✅ 初始化SQLite数据库
- ✅ 配置systemd服务（开机自启）
- ✅ 配置防火墙（开放8080端口）
- ✅ 启动MCP服务器

### 第3步：测试验证

```bash
# 在服务器上运行测试
python3 test_mcp.py
```

如果看到 **"🎉 所有测试通过！"**，说明部署成功！

---

## 🔧 在Claude中配置MCP

### 方法1：自动配置（推荐）

1. 打开 Claude.ai → 设置 → Integrations
2. 点击 "Import MCP Configuration"
3. 上传 `mcp_config.json` 文件
4. 点击 "Test Connection"
5. 看到 ✅ Connected → 完成！

### 方法2：手动配置

1. 打开 Claude.ai → 设置 → Integrations
2. 点击 "Add Custom MCP Server"
3. 填写：

```yaml
名称：龙魂本地系统
描述：连接华为云服务器的龙魂数字主权系统
服务器URL：http://119.13.90.27:8080
API密钥：#CONFIRM🌌9622-ONLY-ONCE🧬LONGHUN-MCP-001
```

4. 添加工具（复制 `mcp_config.json` 中的工具定义）
5. 保存并测试

---

## 🎯 可以做什么

配置完成后，你可以直接对Claude说：

```yaml
查询DNA码：
  "用龙魂本地系统查询DNA码 #龙芯⚡️2026-02-21-XXX"

创建DNA码：
  "用龙魂本地系统创建一个DNA码，项目名是'XXX'"

同步Notion：
  "用龙魂本地系统同步Notion"

运行审计：
  "用龙魂本地系统审计这段文字：'...'"

查看状态：
  "用龙魂本地系统查看系统状态"

存储记忆：
  "用龙魂本地系统存储这段对话"

触发备份：
  "用龙魂本地系统触发备份"
```

**核心理念**：
- ✅ 数据在你自己的华为云上
- ✅ 逻辑你自己写，自己说了算
- ✅ 不经过任何第三方
- ✅ 完全可控，光明磊落

---

## 📊 MCP工具列表

| 工具名 | 功能 | 参数 |
|--------|------|------|
| query_dna | 查询DNA码 | dna_code |
| create_dna | 创建DNA码 | project_name, uid |
| sync_notion | 同步Notion | 无 |
| run_audit | 三色审计 | target |
| get_system_status | 系统状态 | 无 |
| store_memory | 存储记忆 | uid, content, category |
| trigger_backup | 触发备份 | 无 |

详细说明请查看 `MCP使用说明.md`

---

## 🔍 常用命令

```bash
# 查看服务状态
systemctl status longhun-mcp

# 启动/停止/重启
systemctl start longhun-mcp
systemctl stop longhun-mcp
systemctl restart longhun-mcp

# 查看实时日志
tail -f /home/longhun/logs/mcp_server.log

# 运行测试
python3 test_mcp.py

# 手动测试连接
curl http://119.13.90.27:8080/

# 备份数据库
cp /home/longhun/data/longhun.db /home/longhun/backup/longhun_$(date +%Y%m%d).db
```

---

## 🛡️ 安全提示

1. **API密钥**：已在代码中配置，但建议定期更换
2. **防火墙**：部署脚本已自动配置，只开放8080端口
3. **HTTPS**：如需HTTPS，请使用Nginx反向代理 + Let's Encrypt证书
4. **日志审计**：定期检查 `/home/longhun/logs/mcp_server.log`
5. **数据备份**：建议每天自动备份数据库到 `/home/longhun/backup/`

---

## 📂 目录结构

```
/home/longhun/
├── mcp/
│   └── longhun_mcp_server.py    # MCP服务器主程序
├── data/
│   └── longhun.db                # SQLite数据库
├── logs/
│   └── mcp_server.log            # 服务器日志
├── scripts/
│   ├── Mac同步.py                # Notion同步脚本
│   ├── 三色审计.py               # 审计脚本
│   └── 备份系统.py               # 备份脚本
└── backup/
    └── longhun_YYYYMMDD.db       # 数据库备份
```

---

## 🆘 故障排除

### 问题1：连接失败

```bash
# 检查服务是否运行
systemctl status longhun-mcp

# 检查端口
netstat -tuln | grep 8080

# 检查防火墙
firewall-cmd --list-ports
```

### 问题2：工具调用失败

```bash
# 查看错误日志
tail -f /home/longhun/logs/mcp_server.log

# 检查数据库
sqlite3 /home/longhun/data/longhun.db ".tables"
```

### 问题3：性能问题

```bash
# 检查系统资源
top
df -h

# 优化数据库
sqlite3 /home/longhun/data/longhun.db "VACUUM;"

# 重启服务
systemctl restart longhun-mcp
```

详细故障排除请参考 `MCP使用说明.md`

---

## 📞 技术支持

**遇到问题？**

1. 先查看 `MCP使用说明.md`
2. 检查日志：`tail -f /home/longhun/logs/mcp_server.log`
3. 运行测试：`python3 test_mcp.py`
4. 联系邮箱：uid9622@petalmail.com

---

## 🎉 部署完成检查清单

- [ ] 文件已上传到服务器
- [ ] 部署脚本运行成功
- [ ] 测试脚本全部通过
- [ ] systemd服务已启动
- [ ] 防火墙端口已开放
- [ ] Claude MCP已配置
- [ ] 工具可以正常调用

**如果以上全部打勾 ✅，恭喜你！龙魂MCP服务器已成功部署！**

---

## 💡 核心理念

```yaml
数据主权：
  ✅ 数据在华为云（中国）
  ✅ 不经过第三方
  ✅ 完全可控

技术主权：
  ✅ 自己的服务器
  ✅ 自己写逻辑
  ✅ 自己说了算

光明磊落：
  ✅ 所有对话有痕迹
  ✅ 不搞小圈子
  ✅ 配合合法执法

为人民服务：
  ✅ 技术平权
  ✅ 普惠全球
  ✅ 祖国优先
```

---

**DNA追溯码**：#龙芯⚡️2026-02-21-MCP项目完整包-v1.0  
**确认码**：#CONFIRM🌌9622-ONLY-ONCE🧬LONGHUN-MCP-PKG-001

**作者**：Lucky (UID9622)  
**协作**：Claude (Anthropic)

**🫡 敬礼！老兵！**  
**🐉 龙魂·为人民服务！**  
**💎 数据主权·自己说了算！**
