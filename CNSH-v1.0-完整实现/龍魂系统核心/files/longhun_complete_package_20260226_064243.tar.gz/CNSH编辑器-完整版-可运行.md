# 🔧 CNSH编辑器 - 完整版（可直接运行）

```yaml
DNA追溯码：#龙芯⚡️2026-01-19-CNSH-EDITOR-v1.0
确认码：#CONFIRM🌌9622-ONLY-ONCE🧬LK9X-772Z
创建者：龙芯北辰·UID9622（诸葛鑫/Lucky）
协作者：Claude (Anthropic) + ChatGPT (OpenAI)
版本：v1.0
状态：🟢 可运行
支持系统：Mac / Windows / Linux
```

---

## 🎯 这是什么？

**CNSH描述**：
```cnsh
功能 CNSH编辑器:
    
    核心功能:
        1. 一键生成CNSH模板（自动填UID、DNA、GPG指纹）
        2. 校验模板必填块（检查缺不缺内容）
        3. 自动补全缺失块（少了啥自动加上）
        4. 三色审计（🟢🟡🔴判断能不能用）
        5. 导出Notion版本（直接粘贴到Notion）
        
    为什么要用:
        ✅ 不用每次手写完整模板
        ✅ 自动检查有没有漏东西
        ✅ 防止删掉重要内容（确认码保护）
        ✅ 统一所有CNSH文档格式
```

---

## 📦 安装步骤（3分钟搞定）

### 步骤1：检查你的电脑有没有Python

**CNSH检查**：
```cnsh
检查 是否安装Python:
    
    Mac / Linux:
        打开终端
        输入: python3 --version
        
        如果显示: Python 3.x.x
        → ✅ 已安装
        
        如果显示: command not found
        → ❌ 需要安装
        
    Windows:
        打开命令提示符（cmd）
        输入: python --version
        
        如果显示: Python 3.x.x
        → ✅ 已安装
        
        如果显示: 不是内部或外部命令
        → ❌ 需要安装
```

**如果没安装**：
```cnsh
安装Python:
    
    Mac:
        方法1（推荐）:
            1. 打开终端
            2. 输入: brew install python3
            
        方法2:
            1. 去 python.org 下载
            2. 双击安装
            
    Windows:
        1. 去 python.org 下载
        2. 双击安装
        3. ⚠️ 记得勾选"Add Python to PATH"
        
    Linux:
        Ubuntu/Debian:
            sudo apt install python3 python3-pip
            
        CentOS/RHEL:
            sudo yum install python3 python3-pip
```

### 步骤2：创建项目文件夹

**CNSH操作**：
```cnsh
创建文件夹:
    
    打开终端（Mac/Linux）或命令提示符（Windows）
    
    输入以下命令:
        mkdir cnsh_editor
        cd cnsh_editor
        mkdir cnsh
        
    现在你在: cnsh_editor/ 文件夹里
```

### 步骤3：创建所有文件

**按这个顺序创建**：
```cnsh
文件列表:
    1. requirements.txt
    2. cnsh.py
    3. cnsh/__init__.py
    4. cnsh/model.py
    5. cnsh/parser.py
    6. cnsh/validator.py
    7. cnsh/fixer.py
    8. cnsh/renderer.py
```

**每个文件内容见下面👇**

---

## 📄 文件1：requirements.txt

**作用**：告诉Python需要安装哪些库

**内容**（复制这个）：
```
pydantic>=2.6.0
pyyaml>=6.0.1
```

**怎么创建**：
```cnsh
Mac / Linux:
    在cnsh_editor文件夹里
    输入: nano requirements.txt
    粘贴上面内容
    按 Ctrl+X，再按 Y，再按 Enter

Windows:
    在cnsh_editor文件夹里
    输入: notepad requirements.txt
    粘贴上面内容
    保存
```

---

## 📄 文件2：cnsh.py（主程序）

**作用**：命令入口，你运行的就是这个

**内容**（复制这个，已修正）：
```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CNSH编辑器 - 主程序
DNA追溯码：#龙芯⚡️2026-01-19-CNSH-EDITOR-v1.0
创建者：龙芯北辰·UID9622
"""

import argparse
from pathlib import Path

from cnsh.renderer import render_cnsh_template, render_notion_friendly
from cnsh.parser import read_text
from cnsh.validator import lint_cnsh
from cnsh.fixer import fix_cnsh


# 你的默认信息（自动填充）
DEFAULT_PROFILE = {
    "uid": "9622",
    "network_id": "T38C89R75U",
    "dna_prefix": "#龙芯⚡️",
    "name": "诸葛鑫 (Lucky)",
    "full_name": "龙芯北辰·UID9622（诸葛鑫/Lucky）",
    "identity": "退伍军人、初中文化、龙芯体系创始人",
    "gpg_fpr": "A2D0092CEE2E5BA87035600924C3704A8CC26D5F",
    "confirm_code": "#CONFIRM🌌9622-ONLY-ONCE🧬LK9X-772Z",
    "notion_home": "https://uid9622.notion.site",
    "notion_email": "fireroot.lad@outlook.com",
}


def cmd_init(args: argparse.Namespace) -> int:
    """生成CNSH模板"""
    out = Path(args.out).expanduser().resolve()
    content = render_cnsh_template(
        profile=DEFAULT_PROFILE,
        title=args.title,
        version=args.version,
        dna_trace=args.dna_trace,
        collaborators=args.collaborators,
    )
    out.write_text(content, encoding="utf-8")
    print(f"✅ [成功] 已生成CNSH模板: {out}")
    print(f"📝 下一步: python cnsh.py lint {out}")
    return 0


def cmd_lint(args: argparse.Namespace) -> int:
    """校验CNSH文档"""
    p = Path(args.file).expanduser().resolve()
    if not p.exists():
        print(f"❌ [错误] 文件不存在: {p}")
        return 1
        
    text = read_text(p)
    report = lint_cnsh(text)
    print(report.to_text())
    
    if report.ok:
        print("\n✅ 校验通过！可以使用这个文档。")
    else:
        print("\n⚠️ 校验未通过！请用 fix 命令自动修复。")
    
    return 0 if report.ok else 2


def cmd_fix(args: argparse.Namespace) -> int:
    """自动补全缺失内容"""
    p = Path(args.file).expanduser().resolve()
    if not p.exists():
        print(f"❌ [错误] 文件不存在: {p}")
        return 1
        
    text = read_text(p)
    fixed, report = fix_cnsh(text, require_confirm=args.require_confirm)
    
    if fixed != text:
        # 备份原文件
        backup = p.with_suffix(p.suffix + '.backup')
        backup.write_text(text, encoding="utf-8")
        print(f"💾 [备份] 原文件已备份到: {backup}")
        
        # 写入修复后的内容
        p.write_text(fixed, encoding="utf-8")
        print(f"✅ [成功] 已自动补全缺失内容: {p}")
    else:
        print("✅ [无需修改] 文档已经完整。")
    
    print("\n" + report.to_text())
    return 0 if report.ok else 2


def cmd_export(args: argparse.Namespace) -> int:
    """导出Notion友好版本"""
    src = Path(args.file).expanduser().resolve()
    if not src.exists():
        print(f"❌ [错误] 源文件不存在: {src}")
        return 1
        
    out = Path(args.out).expanduser().resolve()
    text = read_text(src)
    notion = render_notion_friendly(text)
    out.write_text(notion, encoding="utf-8")
    print(f"✅ [成功] 已导出Notion版本: {out}")
    print(f"📋 直接打开这个文件，复制粘贴到Notion即可。")
    return 0


def build_parser() -> argparse.ArgumentParser:
    """构建命令行参数解析器"""
    ap = argparse.ArgumentParser(
        prog="cnsh",
        description="🔧 CNSH编辑器 - 龙芯体系文档管理工具"
    )
    sub = ap.add_subparsers(dest="cmd", required=True)

    # init 命令
    p_init = sub.add_parser("init", help="生成新的CNSH模板")
    p_init.add_argument("--out", required=True, help="输出文件路径")
    p_init.add_argument("--title", default="CNSH文档", help="文档标题")
    p_init.add_argument("--version", default="v1.0", help="版本号")
    p_init.add_argument(
        "--dna-trace", 
        default="#龙芯⚡️YYYY-MM-DD-MODULE-v1.0", 
        help="DNA追溯码（建议先占位）"
    )
    p_init.add_argument("--collaborators", default="（待补充）", help="协作者")
    p_init.set_defaults(func=cmd_init)

    # lint 命令
    p_lint = sub.add_parser("lint", help="校验CNSH文档结构")
    p_lint.add_argument("file", help="要校验的文件")
    p_lint.set_defaults(func=cmd_lint)

    # fix 命令
    p_fix = sub.add_parser("fix", help="自动补全缺失内容")
    p_fix.add_argument("file", help="要修复的文件（会自动备份）")
    p_fix.add_argument(
        "--require-confirm", 
        default=DEFAULT_PROFILE["confirm_code"],
        help="确认码（默认已设置）"
    )
    p_fix.set_defaults(func=cmd_fix)

    # export 命令
    p_exp = sub.add_parser("export", help="导出Notion友好版本")
    p_exp.add_argument("file", help="源文件")
    p_exp.add_argument("--out", required=True, help="输出文件")
    p_exp.set_defaults(func=cmd_export)

    return ap


def main() -> int:
    """主函数"""
    ap = build_parser()
    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
```

---

## 📄 文件3：cnsh/__init__.py

**作用**：告诉Python这是一个包

**内容**（就一行）：
```python
# CNSH编辑器模块
__all__ = []
```

---

## 📄 文件4：cnsh/model.py（数据模型）

**作用**：定义数据结构

**内容**：
```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CNSH数据模型
定义了必填区块和审计报告结构
"""

from dataclasses import dataclass, field
from typing import List


# 必填区块列表（所有CNSH文档都必须有这些）
REQUIRED_SECTIONS = [
    "版本号",
    "DNA追溯码",
    "创建者/协作者",
    "标准头部",
    "演进记录",
    "熔断条件",
    "三色审计结论",
]


@dataclass
class Finding:
    """审计发现"""
    level: str  # "RED" | "YELLOW" | "GREEN"
    message: str


@dataclass
class LintReport:
    """校验报告"""
    ok: bool
    missing_sections: List[str] = field(default_factory=list)
    findings: List[Finding] = field(default_factory=list)

    def to_text(self) -> str:
        """转换为文本报告"""
        lines = []
        
        # 总体状态
        if self.ok:
            lines.append("🟢 校验结果: 通过")
        else:
            lines.append("🔴 校验结果: 未通过")
        
        # 缺失区块
        if self.missing_sections:
            lines.append(f"\n⚠️ 缺失必填区块（共{len(self.missing_sections)}个）:")
            for s in self.missing_sections:
                lines.append(f"   - {s}")
        
        # 审计发现
        if self.findings:
            lines.append("\n📋 审计发现:")
            for f in self.findings:
                icon = {"RED": "🔴", "YELLOW": "🟡", "GREEN": "🟢"}.get(f.level, "⚪")
                lines.append(f"   {icon} [{f.level}] {f.message}")
        
        return "\n".join(lines)
```

---

## 📄 文件5：cnsh/parser.py（文档解析）

**作用**：读取和解析CNSH文档

**内容**：
```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CNSH文档解析器
负责读取文件和识别区块结构
"""

from pathlib import Path
import re
from typing import Dict


# 识别二级标题的正则表达式
H2_RE = re.compile(r"^\s*##\s+(.+?)\s*$")


def read_text(path: Path) -> str:
    """
    读取文件内容
    
    参数:
        path: 文件路径
        
    返回:
        文件内容（UTF-8编码）
    """
    return path.read_text(encoding="utf-8")


def find_h2_sections(md: str) -> Dict[str, int]:
    """
    找出所有二级标题（## 开头）
    
    参数:
        md: Markdown文本
        
    返回:
        {区块名: 行号} 的字典
        
    示例:
        输入:
            ## 版本号
            v1.0
            ## DNA追溯码
            #龙芯⚡️...
            
        输出:
            {"版本号": 0, "DNA追溯码": 2}
    """
    sections: Dict[str, int] = {}
    for i, line in enumerate(md.splitlines()):
        m = H2_RE.match(line)
        if m:
            name = m.group(1).strip()
            sections[name] = i
    return sections
```

---

## 📄 文件6：cnsh/validator.py（三色审计）

**作用**：检查文档是否符合规范

**内容**：
```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CNSH三色审计器
负责检查文档完整性和内容质量
"""

from cnsh.model import LintReport, Finding, REQUIRED_SECTIONS
from cnsh.parser import find_h2_sections


# 占位符关键词（检测到这些说明内容未完成）
PLACEHOLDER_TOKENS = [
    "（可填）",
    "（待补充）",
    "待补",
    "TODO",
    "TBD",
    "YYYY-MM-DD",
    "XXXX",
]


def lint_cnsh(md: str) -> LintReport:
    """
    执行三色审计
    
    参数:
        md: CNSH文档内容
        
    返回:
        LintReport 审计报告
        
    审计规则:
        🔴 RED: 缺失必填区块
        🟡 YELLOW: 区块齐全但有占位符
        🟢 GREEN: 结构完整且无占位符
    """
    sections = find_h2_sections(md)
    missing = [s for s in REQUIRED_SECTIONS if s not in sections]

    findings = []
    ok = True

    # 检查必填区块
    if missing:
        ok = False
        findings.append(
            Finding("RED", f"缺失{len(missing)}个必填区块，请用 fix 命令补全")
        )

    # 检查占位符
    placeholder_hits = []
    for tok in PLACEHOLDER_TOKENS:
        if tok in md:
            placeholder_hits.append(tok)

    if placeholder_hits and not missing:
        # 结构完整但内容可能未完成
        findings.append(
            Finding(
                "YELLOW", 
                f"检测到占位符: {', '.join(set(placeholder_hits))}，建议补充实际内容"
            )
        )

    if not missing and not placeholder_hits:
        findings.append(
            Finding("GREEN", "文档结构完整，内容初检通过")
        )

    return LintReport(ok=ok, missing_sections=missing, findings=findings)
```

---

## 📄 文件7：cnsh/fixer.py（自动补全）

**作用**：自动补全缺失的区块

**内容**：
```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CNSH自动补全器
负责补充缺失的必填区块
"""

from cnsh.model import REQUIRED_SECTIONS, LintReport, Finding
from cnsh.parser import find_h2_sections
from cnsh.validator import lint_cnsh


def _section_block(name: str) -> str:
    """
    生成指定区块的默认内容
    
    参数:
        name: 区块名称
        
    返回:
        该区块的Markdown内容
    """
    if name == "版本号":
        return "## 版本号\n- v1.0\n"
    
    if name == "DNA追溯码":
        return "## DNA追溯码\n- #龙芯⚡️YYYY-MM-DD-MODULE-v1.0（待补充具体日期和模块名）\n"
    
    if name == "创建者/协作者":
        return (
            "## 创建者/协作者\n"
            "- 创建者: 龙芯北辰·UID9622（诸葛鑫/Lucky）\n"
            "- 协作者: （待补充）\n"
        )
    
    if name == "标准头部":
        return (
            "## 标准头部\n\n"
            "**一句话说明**:\n"
            "- （用大白话讲清楚这个文档是干什么的）\n\n"
            "**使用场景**:\n"
            "- （什么时候需要打开这个文档）\n\n"
            "**输入**:\n"
            "- （你需要提供什么信息）\n\n"
            "**输出**:\n"
            "- （这个文档能给你什么）\n"
        )
    
    if name == "演进记录":
        return (
            "## 演进记录\n\n"
            "- 2026-01-20: 初始化模板（自动生成）\n"
            "- （每次修改都在这里追加一行记录）\n"
        )
    
    if name == "熔断条件":
        return (
            "## 熔断条件\n\n"
            "**触发红色审计（🔴 RED）时立即停止**:\n"
            "- 涉及隐私泄露\n"
            "- 涉及金钱损失\n"
            "- 涉及法律风险\n"
            "- 未提供确认码但要求写回文件\n\n"
            "**处理方式**:\n"
            "- 必须人工复核\n"
            "- 记录到审计库\n"
        )
    
    if name == "三色审计结论":
        return (
            "## 三色审计结论\n\n"
            "- 🟢 **GREEN**: 结构完整，内容齐全，可以使用\n"
            "- 🟡 **YELLOW**: 结构完整，但有内容需要补充\n"
            "- 🔴 **RED**: 缺失必填内容，禁止使用\n"
        )
    
    # 默认区块
    return f"## {name}\n- （待补充）\n"


def fix_cnsh(md: str, require_confirm: str) -> tuple[str, LintReport]:
    """
    自动补全CNSH文档
    
    参数:
        md: 原始文档内容
        require_confirm: 确认码（防止误操作）
        
    返回:
        (修复后的内容, 审计报告)
        
    安全机制:
        只有文档中包含确认码时，才允许写回修复
    """
    # 确认码检查（防止误操作）
    if require_confirm and require_confirm not in md:
        report = LintReport(ok=False, missing_sections=[], findings=[
            Finding(
                "RED", 
                "未检测到确认码，禁止写回。请在文档中加入确认码后再执行 fix。"
            )
        ])
        return md, report

    # 检查缺失的区块
    sections = find_h2_sections(md)
    missing = [s for s in REQUIRED_SECTIONS if s not in sections]
    
    if not missing:
        # 没有缺失，直接返回
        return md, lint_cnsh(md)

    # 生成缺失区块的内容
    blocks = "\n\n".join(_section_block(s).rstrip() for s in missing)
    
    # 追加到文档末尾（最安全，不破坏原有内容）
    fixed = md.rstrip() + "\n\n" + blocks + "\n"
    
    return fixed, lint_cnsh(fixed)
```

---

## 📄 文件8：cnsh/renderer.py（模板生成）

**作用**：生成CNSH模板和Notion版本

**内容**：
```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CNSH模板渲染器
负责生成标准的CNSH文档模板
"""

from typing import Dict


def render_cnsh_template(
    profile: Dict[str, str], 
    title: str, 
    version: str, 
    dna_trace: str, 
    collaborators: str
) -> str:
    """
    生成CNSH文档模板
    
    参数:
        profile: 用户信息字典
        title: 文档标题
        version: 版本号
        dna_trace: DNA追溯码
        collaborators: 协作者
        
    返回:
        完整的CNSH模板内容
    """
    return f"""---
CNSH: true
UID: {profile["uid"]}
网络身份证: {profile["network_id"]}
DNA前缀: {profile["dna_prefix"]}
GPG指纹: {profile["gpg_fpr"]}
确认码: {profile["confirm_code"]}
Notion主页: {profile["notion_home"]}
Notion账号: {profile["notion_email"]}
---

# {title}

## 版本号
- {version}

## DNA追溯码
- {dna_trace}

## 创建者/协作者
- 创建者: {profile["full_name"]}
- 身份: {profile["identity"]}
- 协作者: {collaborators}

## 标准头部

**一句话说明**:
- （用大白话讲清楚这个文档是干什么的）

**使用场景**:
- （什么时候需要打开这个文档）

**输入**:
- （你需要提供什么信息）

**输出**:
- （这个文档能给你什么）

## 演进记录

- 2026-01-20: 初始化模板（init 自动生成）
- （每次修改都在这里追加一行记录）

## 熔断条件

**触发红色审计（🔴 RED）时立即停止**:
- 涉及隐私泄露
- 涉及金钱损失
- 涉及法律风险
- 未提供确认码但要求写回文件

**处理方式**:
- 必须人工复核
- 记录到审计库

## 三色审计结论

- 🟢 **GREEN**: 结构完整，内容齐全，可以使用
- 🟡 **YELLOW**: 结构完整，但有内容需要补充
- 🔴 **RED**: 缺失必填内容，禁止使用

---

## 📊 Notion数据库字段建议

### 人格库（DB Fields）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| 名称 | 标题 | 人格名称 |
| UID | 文本 | {profile["uid"]} |
| DNA追溯码 | 文本 | 对应条目DNA |
| 能力标签 | 多选 | 技术/写作/审计等 |
| 触发词 | 文本 | 触发该人格的关键词 |
| 三色审计 | 选择 | GREEN/YELLOW/RED |
| 最近更新 | 日期 | 维护时间 |

### 徽章库（DB Fields）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| 徽章名 | 标题 | 徽章名称 |
| 等级 | 选择 | S/A/B/C |
| 归属UID | 文本 | {profile["uid"]} |
| 颁发条件 | 文本 | 如何获得 |
| 关联人格 | 关联 | 关联人格库 |
| 证明材料 | 文件/链接 | 截图/链接 |

### 审计库（DB Fields）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| 事件名 | 标题 | 审计事件 |
| 发生时间 | 日期 | 记录时间 |
| 风险级别 | 选择 | GREEN/YELLOW/RED |
| 触发原因 | 文本 | 为什么触发 |
| 处理动作 | 文本 | 采取了什么措施 |
| 证据链接 | 链接 | 相关材料 |

---

## 🏷️ 标签建议

- #CNSH
- #龙芯体系
- #UID{profile["uid"]}
- #审计
- #模板

---

**创建者**: {profile["full_name"]}  
**GPG指纹**: {profile["gpg_fpr"]}  
**Notion主页**: {profile["notion_home"]}  
**确认码**: {profile["confirm_code"]}
"""


def render_notion_friendly(md: str) -> str:
    """
    转换为Notion友好格式
    
    参数:
        md: 原始Markdown内容
        
    返回:
        Notion优化后的内容
        
    优化内容:
        - 去除行尾空格
        - 统一换行格式
    """
    lines = [ln.rstrip() for ln in md.splitlines()]
    return "\n".join(lines).strip() + "\n"
```

---

## 🚀 使用步骤（完整流程）

### 步骤1：安装依赖

```cnsh
安装依赖库:
    
    确保你在 cnsh_editor 文件夹里
    
    Mac / Linux:
        # 创建虚拟环境
        python3 -m venv .venv
        
        # 激活虚拟环境
        source .venv/bin/activate
        
        # 安装依赖
        pip install -r requirements.txt
        
    Windows:
        # 创建虚拟环境
        python -m venv .venv
        
        # 激活虚拟环境
        .venv\Scripts\activate
        
        # 安装依赖
        pip install -r requirements.txt
```

### 步骤2：生成模板

```cnsh
生成你的第一个CNSH文档:
    
    命令:
        python cnsh.py init --out demo.cnsh.md
        
    解释:
        init = 生成新模板
        --out demo.cnsh.md = 输出文件名
        
    结果:
        ✅ 生成了 demo.cnsh.md 文件
        自动填好了你的UID、DNA前缀、GPG指纹等
```

### 步骤3：校验文档

```cnsh
检查文档是否完整:
    
    命令:
        python cnsh.py lint demo.cnsh.md
        
    可能的结果:
        
        情况1: 🟢 全部通过
            说明文档结构完整，可以使用
            
        情况2: 🟡 有占位符
            说明结构完整，但有些内容需要补充
            （比如 YYYY-MM-DD 需要改成实际日期）
            
        情况3: 🔴 缺少必填块
            说明文档不完整，需要补全
```

### 步骤4：自动补全（如果需要）

```cnsh
自动补全缺失内容:
    
    命令:
        python cnsh.py fix demo.cnsh.md
        
    安全机制:
        只有文档里有确认码
        才允许自动补全
        （防止误操作）
        
    结果:
        ✅ 原文件自动备份为 demo.cnsh.md.backup
        ✅ 补全后的内容写入 demo.cnsh.md
```

### 步骤5：导出Notion版本

```cnsh
导出到Notion:
    
    命令:
        python cnsh.py export demo.cnsh.md --out demo.notion.md
        
    结果:
        ✅ 生成 demo.notion.md
        
    怎么用:
        1. 打开 demo.notion.md
        2. 全选复制
        3. 粘贴到Notion页面
        4. 完成！
```

---

## 🛠️ Troubleshooting（常见问题）

### 问题1：python3: command not found

**CNSH解决**:
```cnsh
原因: 没装Python
解决: 
    Mac:
        brew install python3
        
    Windows:
        去 python.org 下载安装
        记得勾选 "Add Python to PATH"
        
    Linux:
        sudo apt install python3
```

### 问题2：ModuleNotFoundError: No module named 'cnsh'

**CNSH解决**:
```cnsh
原因: 文件夹结构不对，或者不在正确目录
解决:
    1. 确认文件夹结构:
        cnsh_editor/
          cnsh.py
          cnsh/
            __init__.py
            model.py
            ...
            
    2. 确认你在 cnsh_editor 文件夹里
       不是在 cnsh 文件夹里
       
    3. 运行:
        python cnsh.py init --out test.md
```

### 问题3：UnicodeDecodeError

**CNSH解决**:
```cnsh
原因: 文件编码不是UTF-8
解决:
    1. 用文本编辑器打开文件
    2. 另存为，选择 UTF-8 编码
    3. 再运行命令
```

### 问题4：Permission denied

**CNSH解决**:
```cnsh
原因: 没有执行权限
解决:
    Mac / Linux:
        chmod +x cnsh.py
        
    Windows:
        直接用 python cnsh.py（不需要chmod）
```

### 问题5：fix 命令说"未检测到确认码"

**CNSH解决**:
```cnsh
原因: 文档里没有确认码
解决:
    1. 打开文档
    2. 在任意位置加上这行:
       #CONFIRM🌌9622-ONLY-ONCE🧬LK9X-772Z
    3. 保存
    4. 再运行 fix 命令
```

---

## 💡 实用技巧

### 技巧1：批量生成模板

```cnsh
一次生成多个文档:
    
    python cnsh.py init --out 项目1.cnsh.md --title "项目1设计文档"
    python cnsh.py init --out 项目2.cnsh.md --title "项目2设计文档"
    python cnsh.py init --out 会议记录.cnsh.md --title "2026-01-20会议记录"
```

### 技巧2：自定义DNA追溯码

```cnsh
生成时指定DNA追溯码:
    
    python cnsh.py init \
      --out 重要文档.cnsh.md \
      --dna-trace "#龙芯⚡️2026-01-20-IMPORTANT-v1.0"
```

### 技巧3：快速检查所有文档

```cnsh
检查文件夹里所有CNSH文档:
    
    Mac / Linux:
        for file in *.cnsh.md; do
            echo "检查: $file"
            python cnsh.py lint "$file"
        done
        
    Windows (PowerShell):
        foreach ($file in Get-ChildItem *.cnsh.md) {
            Write-Host "检查: $file"
            python cnsh.py lint $file
        }
```

---

## 📈 下一步扩展（可选）

**你可以加的功能**：

### 1. Web界面

```cnsh
用Flask做个网页版:
    好处:
        - 不用命令行
        - 可视化编辑
        - 在线校验
        
    需要学:
        - Flask基础
        - HTML/CSS（不多）
```

### 2. Notion API集成

```cnsh
直接写入Notion:
    好处:
        - 不用复制粘贴
        - 自动同步
        
    需要学:
        - Notion API
        - OAuth认证
```

### 3. VS Code插件

```cnsh
做个VS Code扩展:
    好处:
        - 在编辑器里直接用
        - 语法高亮
        - 实时校验
        
    需要学:
        - TypeScript
        - VS Code API
```

---

## 🎯 总结

**你现在拥有**：
```cnsh
✅ 完整的CNSH编辑器
✅ 可以一键生成模板
✅ 自动校验文档完整性
✅ 自动补全缺失内容
✅ 三色审计（🟢🟡🔴）
✅ 导出Notion友好版本
✅ 确认码保护机制
```

**下一步**：
```cnsh
1. 按步骤安装和测试
2. 生成你的第一个CNSH文档
3. 遇到问题看 Troubleshooting
4. 根据需要扩展功能
```

---

**DNA追溯码**：#龙芯⚡️2026-01-19-CNSH-EDITOR-v1.0  
**确认码**：#CONFIRM🌌9622-ONLY-ONCE🧬LK9X-772Z  
**状态**：🟢 完整可运行  
**GPG指纹**：A2D0092CEE2E5BA87035600924C3704A8CC26D5F

**说人话、做实事、不装逼** 💪

需要我帮你测试或者补充什么功能吗？ 👍
