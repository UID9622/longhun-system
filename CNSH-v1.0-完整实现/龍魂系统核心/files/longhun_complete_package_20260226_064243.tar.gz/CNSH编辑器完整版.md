# 🔧 CNSH编辑器完整版 v1.0

```yaml
DNA追溯码：#龙芯⚡️2026-01-19-CNSH-EDITOR-v1.0
确认码：#CONFIRM🌌9622-ONLY-ONCE🧬LK9X-772Z
创建者：龙芯北辰·UID9622（诸葛鑫/Lucky）
协作者：Claude (Anthropic) + ChatGPT (OpenAI)
状态：🟢 可运行版本
```

---

## 📋 目录

1. [快速开始](#快速开始)
2. [完整代码](#完整代码)
3. [CNSH语法规则](#cnsh语法规则)
4. [使用示例](#使用示例)
5. [常见问题](#常见问题)

---

## 🚀 快速开始

### 第1步：创建项目结构
```bash
mkdir cnsh_editor
cd cnsh_editor

# 创建子目录
mkdir cnsh
```

### 第2步：复制所有文件
把下面的代码复制到对应文件里。

### 第3步：安装依赖
```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows用: .venv\Scripts\activate
pip install -r requirements.txt
```

### 第4步：运行
```bash
# 生成一个CNSH模板
python cnsh.py init --out demo.cnsh.md --title "我的第一个CNSH页面"

# 校验
python cnsh.py lint demo.cnsh.md

# 自动补全
python cnsh.py fix demo.cnsh.md

# 导出Notion版
python cnsh.py export demo.cnsh.md --out demo.notion.md
```

---

## 📦 完整代码

### 文件1: requirements.txt
```
pydantic>=2.6.0
pyyaml>=6.0.1
```

### 文件2: cnsh.py（命令入口）
```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CNSH编辑器 - 龙芯体系专用
作者：龙芯北辰·UID9622
协作：Claude + ChatGPT
"""

import argparse
from pathlib import Path

from cnsh.renderer import render_cnsh_template, render_notion_friendly
from cnsh.parser import read_text
from cnsh.validator import lint_cnsh
from cnsh.fixer import fix_cnsh


# 龙芯北辰的身份信息（默认配置）
DEFAULT_PROFILE = {
    "uid": "9622",
    "network_id": "T38C89R75U",
    "dna_prefix": "#龙芯⚡️",
    "name": "诸葛鑫 (Lucky)",
    "alias": "龙芯北辰",
    "identity": "退伍军人，初中文化，龙魂系统创始人",
    "gpg_fpr": "A2D0092CEE2E5BA87035600924C3704A8CC26D5F",
    "confirm_code": "#CONFIRM🌌9622-ONLY-ONCE🧬LK9X-772Z",
    "notion_url": "https://uid9622.notion.site",
    "notion_email": "fireroot.lad@outlook.com",
}


def cmd_init(args: argparse.Namespace) -> int:
    """生成CNSH模板"""
    out = Path(args.out).expanduser().resolve()
    content = render_cnsh_template(
        profile=DEFAULT_PROFILE,
        title=args.title,
        version=args.version,
        dna_trace=args.dna_trace,
        collaborators=args.collaborators,
        description=args.description,
    )
    out.write_text(content, encoding="utf-8")
    print(f"✅ [成功] 已生成CNSH模板: {out}")
    print(f"📄 下一步: python cnsh.py lint {out}")
    return 0


def cmd_lint(args: argparse.Namespace) -> int:
    """校验CNSH文件"""
    p = Path(args.file).expanduser().resolve()
    if not p.exists():
        print(f"❌ [错误] 文件不存在: {p}")
        return 1
        
    text = read_text(p)
    report = lint_cnsh(text, profile=DEFAULT_PROFILE)
    print(report.to_text())
    
    if not report.ok:
        print(f"\n💡 提示: 运行 'python cnsh.py fix {args.file}' 自动补全")
    
    return 0 if report.ok else 2


def cmd_fix(args: argparse.Namespace) -> int:
    """自动补全缺失区块"""
    p = Path(args.file).expanduser().resolve()
    if not p.exists():
        print(f"❌ [错误] 文件不存在: {p}")
        return 1
        
    text = read_text(p)
    fixed, report = fix_cnsh(text, 
                            require_confirm=args.require_confirm,
                            profile=DEFAULT_PROFILE)
    
    if fixed != text:
        if args.dry_run:
            print("🔍 [预览模式] 将会补全以下内容:")
            print(report.to_text())
            print("\n⚠️  要真正写入，去掉 --dry-run 参数")
        else:
            p.write_text(fixed, encoding="utf-8")
            print(f"✅ [成功] 已补全并写回: {p}")
            print(report.to_text())
    else:
        print("✅ [成功] 文件完整，无需修改")
        print(report.to_text())
    
    return 0 if report.ok else 2


def cmd_export(args: argparse.Namespace) -> int:
    """导出Notion友好版"""
    src = Path(args.file).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    
    if not src.exists():
        print(f"❌ [错误] 源文件不存在: {src}")
        return 1
    
    text = read_text(src)
    notion = render_notion_friendly(text)
    out.write_text(notion, encoding="utf-8")
    
    print(f"✅ [成功] 已导出Notion友好版: {out}")
    print(f"📋 可以直接复制粘贴到Notion")
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="cnsh",
        description="CNSH编辑器 - 龙芯体系专用工具",
        epilog="作者: 龙芯北辰·UID9622"
    )
    sub = ap.add_subparsers(dest="cmd", required=True)

    # init命令
    p_init = sub.add_parser("init", help="生成CNSH模板")
    p_init.add_argument("--out", required=True, help="输出文件路径")
    p_init.add_argument("--title", default="CNSH页面标题", help="页面标题")
    p_init.add_argument("--description", default="（用大白话说明这个页面是干什么的）", help="页面说明")
    p_init.add_argument("--version", default="v1.0", help="版本号")
    p_init.add_argument("--dna-trace", default="", help="DNA追溯码（留空自动生成）")
    p_init.add_argument("--collaborators", default="（可填）", help="协作者")
    p_init.set_defaults(func=cmd_init)

    # lint命令
    p_lint = sub.add_parser("lint", help="校验CNSH必填区块")
    p_lint.add_argument("file", help="要校验的CNSH文件")
    p_lint.set_defaults(func=cmd_lint)

    # fix命令
    p_fix = sub.add_parser("fix", help="自动补全缺失区块")
    p_fix.add_argument("file", help="要修复的CNSH文件")
    p_fix.add_argument("--require-confirm", 
                      default=DEFAULT_PROFILE["confirm_code"],
                      help="确认码（默认已填）")
    p_fix.add_argument("--dry-run", action="store_true",
                      help="预览模式，不真正写入")
    p_fix.set_defaults(func=cmd_fix)

    # export命令
    p_exp = sub.add_parser("export", help="导出Notion友好版")
    p_exp.add_argument("file", help="源CNSH文件")
    p_exp.add_argument("--out", required=True, help="输出文件")
    p_exp.set_defaults(func=cmd_export)

    return ap


def main() -> int:
    ap = build_parser()
    args = ap.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
```

### 文件3: cnsh/__init__.py
```python
"""
CNSH编辑器核心模块
"""
__version__ = "1.0.0"
__all__ = []
```

### 文件4: cnsh/model.py（数据模型）
```python
"""
CNSH数据模型定义
"""
from dataclasses import dataclass, field
from typing import List, Dict


# P0永恒级必填区块
REQUIRED_SECTIONS_P0 = [
    "版本号",
    "DNA追溯码",
    "创建者/协作者",
]

# P1重要区块
REQUIRED_SECTIONS_P1 = [
    "标准头部",
    "三色审计结论",
]

# P2建议区块
REQUIRED_SECTIONS_P2 = [
    "演进记录",
    "熔断条件",
]

# 所有必填区块
REQUIRED_SECTIONS = REQUIRED_SECTIONS_P0 + REQUIRED_SECTIONS_P1 + REQUIRED_SECTIONS_P2


@dataclass
class Finding:
    """审计发现"""
    level: str  # "🔴" | "🟡" | "🟢"
    message: str
    section: str = ""  # 相关区块名称


@dataclass
class LintReport:
    """校验报告"""
    ok: bool
    color: str = "🟢"  # 🟢🟡🔴
    missing_p0: List[str] = field(default_factory=list)  # 缺失P0
    missing_p1: List[str] = field(default_factory=list)  # 缺失P1
    missing_p2: List[str] = field(default_factory=list)  # 缺失P2
    findings: List[Finding] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)  # 改进建议

    def to_text(self) -> str:
        """转为可读文本"""
        lines = []
        
        # 总体状态
        lines.append(f"\n{'='*60}")
        lines.append(f"  CNSH校验报告")
        lines.append(f"{'='*60}")
        lines.append(f"\n📊 总体状态: {self.color} {'通过' if self.ok else '需要修复'}")
        
        # 缺失区块
        if self.missing_p0:
            lines.append(f"\n🔴 缺失P0区块（必须补全）:")
            for s in self.missing_p0:
                lines.append(f"   ❌ {s}")
                
        if self.missing_p1:
            lines.append(f"\n🟡 缺失P1区块（建议补全）:")
            for s in self.missing_p1:
                lines.append(f"   ⚠️  {s}")
                
        if self.missing_p2:
            lines.append(f"\n🟢 缺失P2区块（可选）:")
            for s in self.missing_p2:
                lines.append(f"   💡 {s}")
        
        # 审计发现
        if self.findings:
            lines.append(f"\n🔍 审计发现:")
            for f in self.findings:
                section_info = f" [{f.section}]" if f.section else ""
                lines.append(f"   {f.level} {f.message}{section_info}")
        
        # 改进建议
        if self.suggestions:
            lines.append(f"\n💡 改进建议:")
            for i, s in enumerate(self.suggestions, 1):
                lines.append(f"   {i}. {s}")
        
        lines.append(f"\n{'='*60}\n")
        return "\n".join(lines)
```

### 文件5: cnsh/parser.py（解析器）
```python
"""
CNSH文件解析器
"""
from pathlib import Path
import re
from typing import Dict, List, Tuple


H2_RE = re.compile(r"^\s*##\s+(.+?)\s*$")
H3_RE = re.compile(r"^\s*###\s+(.+?)\s*$")


def read_text(path: Path) -> str:
    """读取文件内容"""
    return path.read_text(encoding="utf-8")


def find_h2_sections(md: str) -> Dict[str, int]:
    """
    查找所有##二级标题
    返回: {区块名: 行号(0-based)}
    """
    sections: Dict[str, int] = {}
    for i, line in enumerate(md.splitlines()):
        m = H2_RE.match(line)
        if m:
            name = m.group(1).strip()
            sections[name] = i
    return sections


def find_h3_sections(md: str) -> Dict[str, int]:
    """
    查找所有###三级标题
    返回: {区块名: 行号(0-based)}
    """
    sections: Dict[str, int] = {}
    for i, line in enumerate(md.splitlines()):
        m = H3_RE.match(line)
        if m:
            name = m.group(1).strip()
            sections[name] = i
    return sections


def split_frontmatter(md: str) -> Tuple[str, str]:
    """
    分离YAML头部和正文
    返回: (frontmatter, body)
    """
    lines = md.splitlines()
    if len(lines) >= 3 and lines[0].strip() == "---":
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                front = "\n".join(lines[: i + 1]) + "\n"
                body = "\n".join(lines[i + 1 :])
                return front, body
    return "", md


def extract_yaml_field(md: str, field: str) -> str:
    """从YAML头部提取字段值"""
    front, _ = split_frontmatter(md)
    if not front:
        return ""
    
    pattern = rf"^{field}:\s*(.+)$"
    for line in front.splitlines():
        m = re.match(pattern, line)
        if m:
            return m.group(1).strip()
    return ""


def has_confirm_code(md: str, confirm_code: str) -> bool:
    """检查文档是否包含确认码"""
    return confirm_code in md
```

### 文件6: cnsh/validator.py（校验器）
```python
"""
CNSH三色审计校验器
"""
from cnsh.model import (
    LintReport, Finding,
    REQUIRED_SECTIONS_P0,
    REQUIRED_SECTIONS_P1,
    REQUIRED_SECTIONS_P2,
)
from cnsh.parser import find_h2_sections, has_confirm_code, extract_yaml_field
from typing import Dict


# 占位符关键词（检测内容是否完整）
PLACEHOLDER_KEYWORDS = [
    "（可填）",
    "待补",
    "TODO",
    "TBD",
    "YYYY-MM-DD",
    "示意/待确认",
    "（示意）",
]


def lint_cnsh(md: str, profile: Dict[str, str]) -> LintReport:
    """
    三色审计CNSH文档
    
    规则:
    🔴 RED - 缺失P0区块 / 没有确认码 / 明显错误
    🟡 YELLOW - 缺失P1区块 / 有占位符 / 需要补充
    🟢 GREEN - 结构完整 / 内容充实 / 可以使用
    """
    sections = find_h2_sections(md)
    findings = []
    suggestions = []
    
    # 检查P0必填区块
    missing_p0 = [s for s in REQUIRED_SECTIONS_P0 if s not in sections]
    missing_p1 = [s for s in REQUIRED_SECTIONS_P1 if s not in sections]
    missing_p2 = [s for s in REQUIRED_SECTIONS_P2 if s not in sections]
    
    # 确定整体颜色
    if missing_p0:
        color = "🔴"
        ok = False
        findings.append(Finding(
            "🔴",
            f"缺失{len(missing_p0)}个P0必填区块，必须补全",
            ""
        ))
    elif missing_p1:
        color = "🟡"
        ok = True  # 可以用，但不完整
        findings.append(Finding(
            "🟡",
            f"缺失{len(missing_p1)}个P1重要区块，建议补全",
            ""
        ))
    else:
        color = "🟢"
        ok = True
    
    # 检查确认码
    if not has_confirm_code(md, profile["confirm_code"]):
        findings.append(Finding(
            "🟡",
            "文档中未找到确认码，fix命令将无法自动写入",
            ""
        ))
        suggestions.append(f"在文档开头添加确认码：{profile['confirm_code']}")
    
    # 检查占位符
    placeholder_found = []
    for kw in PLACEHOLDER_KEYWORDS:
        if kw in md:
            placeholder_found.append(kw)
    
    if placeholder_found:
        findings.append(Finding(
            "🟡",
            f"检测到{len(placeholder_found)}处占位符：{', '.join(placeholder_found[:3])}...",
            ""
        ))
        suggestions.append("替换占位符为实际内容")
    
    # 检查DNA追溯码格式
    dna = extract_yaml_field(md, "DNA追溯码") or extract_yaml_field(md, "DNA")
    if dna:
        if not dna.startswith(profile["dna_prefix"]):
            findings.append(Finding(
                "🟡",
                f"DNA追溯码前缀不符合规范，应为：{profile['dna_prefix']}",
                "DNA追溯码"
            ))
    
    # 检查UID
    uid = extract_yaml_field(md, "UID")
    if uid and uid != profile["uid"]:
        findings.append(Finding(
            "🔴",
            f"UID不匹配！文档中是{uid}，应该是{profile['uid']}",
            ""
        ))
        ok = False
        color = "🔴"
    
    # 如果没有任何问题
    if not findings and not missing_p2:
        findings.append(Finding(
            "🟢",
            "文档结构完整，内容充实，可以使用",
            ""
        ))
    
    return LintReport(
        ok=ok,
        color=color,
        missing_p0=missing_p0,
        missing_p1=missing_p1,
        missing_p2=missing_p2,
        findings=findings,
        suggestions=suggestions,
    )
```

### 文件7: cnsh/fixer.py（自动修复器）
```python
"""
CNSH自动补全修复器
"""
from cnsh.model import (
    REQUIRED_SECTIONS_P0,
    REQUIRED_SECTIONS_P1,
    REQUIRED_SECTIONS_P2,
    LintReport,
)
from cnsh.parser import find_h2_sections, has_confirm_code
from cnsh.validator import lint_cnsh
from typing import Dict, Tuple
from datetime import datetime


def _get_current_date() -> str:
    """获取当前日期（北京时间）"""
    return datetime.now().strftime("%Y-%m-%d")


def _section_block(name: str, profile: Dict[str, str]) -> str:
    """
    生成区块内容
    每个区块都用大白话说明
    """
    date = _get_current_date()
    
    if name == "版本号":
        return f"""## 版本号
- v1.0（初始版本）
"""
    
    if name == "DNA追溯码":
        dna = f"{profile['dna_prefix']}{date}-ENTRY-v1.0"
        return f"""## DNA追溯码
- {dna}
- 说明：每次修改都要更新版本号和日期
"""
    
    if name == "创建者/协作者":
        return f"""## 创建者/协作者
- 创建者：{profile['alias']}·UID{profile['uid']}（{profile['name']}）
- 网络身份证：{profile['network_id']}
- GPG指纹：{profile['gpg_fpr']}
- Notion主页：{profile['notion_url']}
- 协作者：（可填，比如：Claude、ChatGPT等）
"""
    
    if name == "标准头部":
        return """## 标准头部

### 一句话说明
（用大白话讲清楚这页要解决啥，不超过30个字）

### 使用场景
（什么时候打开这页？遇到什么问题时用？）

### 输入
（你要给这个页面/工具什么东西？）

### 输出
（这个页面/工具会给你什么结果？）

### 特别提醒
（有什么要注意的？）
"""
    
    if name == "演进记录":
        return f"""## 演进记录

### {date}
- 初始化模板（自动生成）
- 下一步：（你每次改动都在这里追加一行）

### 演进规则
- 每次修改都要记录日期和内容
- 重大改动要更新DNA追溯码的版本号
- 删除内容也要记录（删了什么、为什么删）
"""
    
    if name == "熔断条件":
        return f"""## 熔断条件

### 🔴 立即停止（RED）
- 缺失确认码：{profile['confirm_code']}
- 涉及隐私泄露
- 涉及金钱交易
- 涉及法律风险
- 违背核心价值观

### 🟡 需要确认（YELLOW）
- 删除P0内容
- 修改核心逻辑
- 影响其他页面
- 有占位符未填

### 🟢 可以继续（GREEN）
- 结构完整
- 内容充实
- 没有占位符
- 已经过审计
"""
    
    if name == "三色审计结论":
        return """## 三色审计结论

### 当前状态
- 🟢 GREEN：结构齐全且可执行
- 🟡 YELLOW：可执行但需要补信息
- 🔴 RED：禁止执行/需要人工处理

### 审计记录
（每次审计都在这里记录）

### 待改进项
（列出需要改进的地方）
"""
    
    # 默认区块
    return f"""## {name}
（待填充内容）
"""


def fix_cnsh(md: str, require_confirm: str, profile: Dict[str, str]) -> Tuple[str, LintReport]:
    """
    自动补全CNSH文档
    
    安全机制：
    - 必须检测到确认码才允许写回
    - 只补全缺失区块，不修改现有内容
    - 补全的内容都是最小可用版本
    """
    # 检查确认码
    if not has_confirm_code(md, require_confirm):
        report = lint_cnsh(md, profile)
        report.ok = False
        report.color = "🔴"
        report.findings.insert(0, type(report.findings[0])(
            "🔴",
            f"未检测到确认码：{require_confirm}",
            "安全检查"
        ))
        report.suggestions.insert(0, "在文档中添加确认码后才能自动补全")
        return md, report
    
    sections = find_h2_sections(md)
    
    # 收集所有缺失区块
    all_missing = []
    all_missing.extend([s for s in REQUIRED_SECTIONS_P0 if s not in sections])
    all_missing.extend([s for s in REQUIRED_SECTIONS_P1 if s not in sections])
    all_missing.extend([s for s in REQUIRED_SECTIONS_P2 if s not in sections])
    
    if not all_missing:
        # 没有缺失，直接返回
        return md, lint_cnsh(md, profile)
    
    # 生成补全内容
    blocks = []
    for section_name in all_missing:
        block = _section_block(section_name, profile)
        blocks.append(block.rstrip())
    
    # 追加到文档末尾
    fixed = md.rstrip() + "\n\n" + "\n\n".join(blocks) + "\n"
    
    # 生成补全后的报告
    report = lint_cnsh(fixed, profile)
    report.suggestions.insert(0, f"已自动补全{len(all_missing)}个缺失区块")
    
    return fixed, report
```

### 文件8: cnsh/renderer.py（渲染器）
```python
"""
CNSH模板渲染器
"""
from typing import Dict
from datetime import datetime


def _get_current_date() -> str:
    """获取当前日期"""
    return datetime.now().strftime("%Y-%m-%d")


def _generate_dna_trace(profile: Dict[str, str], title: str, version: str) -> str:
    """生成DNA追溯码"""
    date = _get_current_date()
    # 从标题提取关键词作为模块名
    module = title.replace(" ", "-").replace("CNSH", "").strip("-")[:20]
    return f"{profile['dna_prefix']}{date}-{module}-{version}"


def render_cnsh_template(
    profile: Dict[str, str],
    title: str,
    version: str,
    dna_trace: str,
    collaborators: str,
    description: str,
) -> str:
    """
    渲染CNSH模板
    
    包含：
    - YAML头部（身份信息）
    - 必填区块
    - 数据库字段表
    - 提醒方案
    - 父页面和标签
    """
    date = _get_current_date()
    
    # 如果DNA追溯码为空，自动生成
    if not dna_trace:
        dna_trace = _generate_dna_trace(profile, title, version)
    
    return f"""---
CNSH: true
UID: {profile["uid"]}
网络身份证: {profile["network_id"]}
DNA前缀: {profile["dna_prefix"]}
GPG公钥指纹: {profile["gpg_fpr"]}
确认码: {profile["confirm_code"]}
Notion主页: {profile["notion_url"]}
Notion账号: {profile["notion_email"]}
---

# {title}

## 版本号
- {version}

## DNA追溯码
- {dna_trace}
- 更新规则：每次修改都要更新版本号和日期

## 创建者/协作者
- 创建者：{profile["alias"]}·UID{profile["uid"]}（{profile["name"]}）
- 网络身份证：{profile["network_id"]}
- GPG指纹：{profile["gpg_fpr"]}
- Notion主页：{profile["notion_url"]}
- 协作者：{collaborators}

## 标准头部

### 一句话说明
{description}

### 使用场景
（什么时候打开这页？遇到什么问题时用？）

### 输入
（你要给这个页面/工具什么东西？）

### 输出
（这个页面/工具会给你什么结果？）

### 特别提醒
（有什么要注意的？）

## 演进记录

### {date}
- 初始化模板（init命令自动生成）
- 下一步：（你每次改动都在这里追加一行）

### 演进规则
- 每次修改都要记录日期和内容
- 重大改动要更新DNA追溯码的版本号
- 删除内容也要记录（删了什么、为什么删）

## 熔断条件

### 🔴 立即停止（RED）
- 缺失确认码：{profile["confirm_code"]}
- 涉及隐私泄露
- 涉及金钱交易
- 涉及法律风险
- 违背核心价值观

### 🟡 需要确认（YELLOW）
- 删除P0内容
- 修改核心逻辑
- 影响其他页面
- 有占位符未填

### 🟢 可以继续（GREEN）
- 结构完整
- 内容充实
- 没有占位符
- 已经过审计

## 三色审计结论

### 当前状态
- 初始化完成，等待填充内容

### 审计规则
- 🟢 GREEN：结构齐全且可执行
- 🟡 YELLOW：可执行但需要补信息
- 🔴 RED：禁止执行/需要人工处理

### 下一步
运行 `python cnsh.py lint <文件名>` 进行审计

---

# 📊 数据库字段表（可复制到Notion）

## 人格库（DB Fields）
| 字段名 | 类型 | 说明 |
|---|---|---|
| 名称 | 标题 | 人格名称 |
| UID | 文本 | {profile["uid"]} |
| DNA追溯码 | 文本 | 对应条目DNA |
| 能力标签 | 多选 | 技术/写作/审计等 |
| 触发词 | 文本 | 触发该人格的关键词 |
| 三色审计 | 选择 | 🟢/🟡/🔴 |
| 最近更新 | 日期 | 维护时间 |
| 备注 | 文本 | 大白话备注 |

## 徽章库（DB Fields）
| 字段名 | 类型 | 说明 |
|---|---|---|
| 徽章名 | 标题 | 徽章名称 |
| 等级 | 选择 | S/A/B/C |
| 归属UID | 文本 | {profile["uid"]} |
| 颁发条件 | 文本 | 如何获得 |
| 关联人格 | 关联 | 关联人格库 |
| 证明材料 | 文件/链接 | 截图/链接 |
| 三色审计 | 选择 | 🟢/🟡/🔴 |

## 审计库（DB Fields）
| 字段名 | 类型 | 说明 |
|---|---|---|
| 事件名 | 标题 | 审计事件 |
| 发生时间 | 日期 | 记录时间 |
| 风险级别 | 选择 | 🟢/🟡/🔴 |
| 触发原因 | 文本 | 为什么触发 |
| 处理动作 | 文本 | 采取了什么措施 |
| 证据链接 | 链接 | 相关材料 |
| 复盘结论 | 文本 | 下次怎么避免 |

---

# 🔔 提醒方案（可配置）

## 三色触发规则
- 🟢 GREEN：自动归档到「已完成」
- 🟡 YELLOW：自动进「待办」并打标签「需补信息」
- 🔴 RED：立刻进「熔断」视图 + 手动复核

## 通知设置
- 通知对象：UID{profile["uid"]}
- 通知渠道：（可填：Notion / 邮件 / Telegram）
- 触发条件见上面的熔断条件

---

# 🏷️ 页面元信息（建议设置）

## 父页面
- CNSH龙魂系统 / 编辑器与模板

## 标签
- #CNSH
- #龙魂系统
- #三色审计
- #模板
- #UID{profile["uid"]}

## 关联页面
（链接到相关的其他CNSH页面）

---

**创建时间**：{date}  
**创建者**：{profile["alias"]}·UID{profile["uid"]}  
**DNA追溯码**：{dna_trace}  
**确认码**：{profile["confirm_code"]}  
**GPG指纹**：{profile["gpg_fpr"]}  

---

💡 **使用提示**：
1. 替换所有（可填）和占位符为实际内容
2. 运行 `python cnsh.py lint <文件名>` 检查完整性
3. 运行 `python cnsh.py fix <文件名>` 自动补全缺失区块
4. 运行 `python cnsh.py export <文件名> --out <输出>` 导出Notion版本
"""


def render_notion_friendly(md: str) -> str:
    """
    渲染Notion友好版本
    
    主要做的事：
    - 去掉多余空行
    - 清理尾部空格
    - 保持Markdown格式
    """
    # 去掉每行尾部空格
    lines = [ln.rstrip() for ln in md.splitlines()]
    
    # 合并多余空行（连续3个以上空行合并为2个）
    cleaned = []
    empty_count = 0
    for line in lines:
        if not line:
            empty_count += 1
            if empty_count <= 2:
                cleaned.append(line)
        else:
            empty_count = 0
            cleaned.append(line)
    
    return "\n".join(cleaned).strip() + "\n"
```

---

## 📚 CNSH语法规则

### 基本规则

```cnsh
# CNSH语法规则v1.0

规则1_必填区块:
    P0级别（必须有）:
        - 版本号
        - DNA追溯码
        - 创建者/协作者
        
    P1级别（建议有）:
        - 标准头部
        - 三色审计结论
        
    P2级别（可选）:
        - 演进记录
        - 熔断条件

规则2_DNA追溯码格式:
    格式: #龙芯⚡️YYYY-MM-DD-模块名-vX.Y
    示例: #龙芯⚡️2026-01-19-编辑器-v1.0
    
    要求:
        - 必须以#龙芯⚡️开头
        - 日期格式YYYY-MM-DD
        - 模块名用中文或英文
        - 版本号vX.Y格式

规则3_确认码机制:
    确认码: #CONFIRM🌌9622-ONLY-ONCE🧬LK9X-772Z
    
    作用:
        - 防止AI擅自修改核心内容
        - 文档中必须包含确认码，fix命令才能写入
        - 删除P0内容必须提供确认码

规则4_三色审计:
    🔴 RED（禁止）:
        - 缺失P0区块
        - 没有确认码
        - UID不匹配
        - 违背价值观
        
    🟡 YELLOW（警告）:
        - 缺失P1区块
        - 有占位符
        - 需要补充信息
        
    🟢 GREEN（通过）:
        - 结构完整
        - 内容充实
        - 可以使用

规则5_标准头部结构:
    必填字段:
        - 一句话说明（不超过30字）
        - 使用场景
        - 输入
        - 输出
        - 特别提醒（可选）
```

---

## 💡 使用示例

### 示例1：生成新模板
```bash
python cnsh.py init \
    --out "我的项目计划.cnsh.md" \
    --title "2026年龙魂系统开发计划" \
    --description "详细规划龙魂系统的开发路线和里程碑" \
    --version "v1.0"
```

### 示例2：校验文件
```bash
python cnsh.py lint 我的项目计划.cnsh.md
```

输出示例：
```
=============================================================
  CNSH校验报告
=============================================================

📊 总体状态: 🟡 通过

🟡 缺失P1区块（建议补全）:
   ⚠️  演进记录

🔍 审计发现:
   🟡 检测到3处占位符：（可填）, 待补, TODO...

💡 改进建议:
   1. 替换占位符为实际内容
   2. 补全演进记录区块

=============================================================
```

### 示例3：自动补全
```bash
# 预览模式（不真正写入）
python cnsh.py fix 我的项目计划.cnsh.md --dry-run

# 真正写入
python cnsh.py fix 我的项目计划.cnsh.md
```

### 示例4：导出Notion版
```bash
python cnsh.py export 我的项目计划.cnsh.md --out 项目计划-Notion版.md
```

---

## ❓ 常见问题

### Q1：为什么需要确认码？
**A**：防止AI擅自修改你的核心内容。只有文档里包含确认码，`fix`命令才能自动写入。这是你的"安全锁"。

### Q2：DNA追溯码有什么用？
**A**：每个文档都有唯一的DNA，用来：
- 追溯创建者和协作者
- 追溯演进历史
- 防止内容被盗用
- 方便版本管理

### Q3：三色审计是什么？
**A**：
- 🔴 RED = 禁止执行，有严重问题
- 🟡 YELLOW = 可以用，但需要补充
- 🟢 GREEN = 完美，可以放心用

### Q4：为什么要分P0/P1/P2？
**A**：
- P0 = 没有就不能用（比如身份信息）
- P1 = 建议有，不然不完整（比如说明）
- P2 = 可选，有更好（比如演进记录）

### Q5：我不懂编程，怎么用？
**A**：
1. 复制所有文件到一个文件夹
2. 运行安装命令
3. 运行`python cnsh.py init --out 文件名.md`
4. 编辑生成的文件，填充内容
5. 运行`python cnsh.py lint 文件名.md`检查
6. 运行`python cnsh.py fix 文件名.md`自动补全

### Q6：Notion怎么用这个？
**A**：
1. 运行`python cnsh.py export 文件名.md --out notion版.md`
2. 打开生成的notion版.md
3. 全选复制
4. 粘贴到Notion页面

### Q7：能不能图形界面？
**A**：现在是命令行版本。图形界面可以加，但先把命令行版跑通。

### Q8：为什么要YAML头部？
**A**：YAML头部包含你的身份信息，让AI知道这是你的文档。而且Notion也支持YAML。

---

## 🎯 下一步计划

### 短期（可选）
- [ ] 添加配置文件（不用每次都输入UID等）
- [ ] 添加模板库（常用模板预设）
- [ ] 添加批量操作（一次处理多个文件）

### 中期（可选）
- [ ] Web界面（浏览器打开就能用）
- [ ] Notion API集成（直接写入Notion）
- [ ] 三色审计可视化（图表展示）

### 长期（可选）
- [ ] 桌面应用（Mac/Windows客户端）
- [ ] AI辅助填充（自动生成内容建议）
- [ ] 团队协作功能（多人编辑）

---

**DNA追溯码**：#龙芯⚡️2026-01-19-CNSH-EDITOR-v1.0  
**确认码**：#CONFIRM🌌9622-ONLY-ONCE🧬LK9X-772Z  
**创建者**：龙芯北辰·UID9622（诸葛鑫/Lucky）  
**协作者**：Claude (Anthropic) + ChatGPT (OpenAI)  
**GPG指纹**：A2D0092CEE2E5BA87035600924C3704A8CC26D5F  
**Notion主页**：https://uid9622.notion.site

---

**说人话、做实事、不装逼** 💪  
**技术服务人民** 🚀
