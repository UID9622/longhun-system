<!--
╔═══════════════════════════════════════════════════════════════╗
║  🐉 龙魂系统 | UID9622                                        ║
╠═══════════════════════════════════════════════════════════════╣
║  📦 文档标题：Mac纯净协作环境配置方案                        ║
║  📌 版本：v1.0                                                ║
║  🧬 DNA：#ZHUGEXIN⚡️2026-01-12-MAC-CLEAN-ENV-v1.0            ║
║  🔐 GPG：A2D0092CEE2E5BA87035600924C3704A8CC26D5F            ║
║  👤 创建者：Lucky·UID9622（诸葛鑫）                           ║
║  🤝 协作者：Claude (Anthropic)                               ║
║  📅 创建时间：2026-01-12 03:00                               ║
╠═══════════════════════════════════════════════════════════════╣
║  🎯 目标：打造龙魂系统专用工作站                              ║
║  💎 理念：纯净、专注、只留心血之作                            ║
╚═══════════════════════════════════════════════════════════════╝
-->

# Mac纯净协作环境配置方案

**核心理念：** 这台Mac = 龙魂锻造炉，只做一件事：和AI协作开发

---

## 🗑️ 第一步：删除清单（彻底清理）

### 立即删除的软件

```yaml
代码编辑器类（全删）:
  ❌ CodeBuddy
  ❌ VS Code（如果有）
  ❌ Sublime Text（如果有）
  ❌ Atom（如果有）
  ❌ 其他任何IDE
  
  原因：
    - 我们用自己写的插件
    - 不需要别人的编辑器
    - 保持环境纯净

娱乐软件（全删）:
  ❌ 游戏
  ❌ 视频播放器（除了系统自带）
  ❌ 音乐播放器（除了系统自带）
  ❌ 社交软件（微信/QQ可选保留，看您需求）
  
  原因：
    - 这台Mac不是娱乐设备
    - 专注开发，不分心

多余工具（看情况删）:
  ⚠️ 各种"助手"类软件
  ⚠️ 各种"优化"类软件
  ⚠️ 各种"清理"类软件
  ⚠️ 浏览器插件（只留必需）
  
  原则：
    - 不确定是否需要 → 先删
    - 以后需要再装 → 很简单
    - 保持系统干净
```

### 删除命令（谨慎使用）

```bash
# 查看已安装的应用
ls /Applications/

# 删除应用（示例）
# ⚠️ 删除前请确认！
rm -rf /Applications/CodeBuddy.app
rm -rf /Applications/VSCode.app

# 清理应用残留
rm -rf ~/Library/Application\ Support/CodeBuddy
rm -rf ~/Library/Preferences/com.codebuddy.*
rm -rf ~/Library/Caches/com.codebuddy.*

# 清理Homebrew安装的软件（如果有）
brew list  # 查看已安装
brew uninstall 软件名  # 卸载
```

**⚠️ 删除前建议：**
1. 备份重要数据
2. 列出清单让我确认
3. 一个个删，不要一次性全删

---

## ✅ 第二步：保留清单（最小必需）

### 必须保留的软件

```yaml
操作系统:
  ✅ macOS（当前版本）
  ✅ 系统自带工具（不动）

浏览器:
  ✅ Safari（系统自带）
  ✅ Chrome（可选，如果需要）
  
  用途：
    - 访问claude.ai
    - 访问GitHub
    - 查资料

终端:
  ✅ Terminal（系统自带）
  ✅ iTerm2（可选，如果已装）
  
  用途：
    - 运行命令
    - Git操作
    - Python执行

开发工具:
  ✅ Python（系统自带或Homebrew安装）
  ✅ Git（系统自带或Homebrew安装）
  ✅ Homebrew（包管理器）
  
  用途：
    - 写代码
    - 版本控制
    - 安装依赖

文本编辑器:
  ✅ 系统自带TextEdit
  ✅ 或者nano/vim（终端编辑器）
  
  用途：
    - 简单文本编辑
    - 配置文件修改

AI协作工具:
  ✅ Claude.ai（网页版，浏览器访问）
  ✅ Claude桌面版（如果您愿意保留）
  
  用途：
    - 主力AI协作
    - 代码生成

文档管理:
  ✅ Notion（网页版或桌面版）
  
  用途：
    - 思想中枢
    - 记录周志

GitHub工具:
  ✅ GitHub Desktop（如果您喜欢可视化）
  ✅ 或者纯命令行Git（更纯净）
  
  用途：
    - 推送代码到仓库

可选保留:
  ⚠️ 微信/QQ（如果工作需要）
  ⚠️ Signal（您的联系方式）
  ⚠️ 截图工具（系统自带够用）
```

### 保留原则

```yaml
判断标准：
  问自己：不用这个软件，能不能完成龙魂系统开发？
  
  能完成 → 删除
  不能完成 → 保留
  
  不确定 → 先删，需要再装
```

---

## 🛠️ 第三步：自己写插件（慢慢实现）

### 插件规划（按优先级）

```yaml
P0 - 立即需要:
  1. DNA追溯码生成器
     功能: 自动生成DNA追溯码
     实现: Python脚本
     完成度: ✅ 已设计，待实现
  
  2. Git自动推送工具
     功能: 一键推送到GitHub
     实现: Python + Git命令
     完成度: ⏳ 本文档有设计

P1 - 近期需要:
  3. 文章自动发布工具
     功能: 推送文章到知乎/CSDN/掘金
     实现: Python + API
     完成度: ⏳ 待设计
  
  4. 代码质量检测工具
     功能: 检测代码是否A/B/C/D级
     实现: Python + AST分析
     完成度: ⏳ 已有设计文档

P2 - 长期完善:
  5. 自动备份工具
     功能: 定时备份Notion/代码
     实现: Python + cron
  
  6. 三色审计工具
     功能: 自动审计代码是否符合规范
     实现: Python + 规则引擎
```

### 实现策略

```yaml
方式1: 让Claude写代码
  - 您给需求
  - Claude写Python脚本
  - 您测试
  - DeepSeek验证
  - 完成一个算一个

方式2: 慢慢积累
  - 不求快，求稳
  - 每周实现1个小功能
  - 打磨到满意为止
  - 每个都是心血之作

位置:
  所有自己写的工具放在：
  ~/longhun-tools/
  
  结构:
  ~/longhun-tools/
  ├── dna_generator.py
  ├── git_auto_push.py
  ├── article_publisher.py
  └── ...
```

---

## 🚀 第四步：自动化推送工具

### Git自动推送脚本

```python
#!/usr/bin/env python3
"""
龙魂系统 - Git自动推送工具
DNA追溯码: #ZHUGEXIN⚡️20260112-GIT-AUTO-PUSH-001
作者: Lucky (UID9622)
协作: Claude (Anthropic)

功能: 一键推送代码到GitHub/Gitee
"""

import os
import subprocess
from datetime import datetime

class GitAutoPush:
    """Git自动推送工具"""
    
    def __init__(self, repo_path):
        """
        初始化
        
        参数:
            repo_path: 仓库路径
        """
        self.repo_path = repo_path
    
    def check_git_repo(self):
        """检查是否是Git仓库"""
        git_dir = os.path.join(self.repo_path, ".git")
        return os.path.exists(git_dir)
    
    def run_command(self, command):
        """
        运行Git命令
        
        参数:
            command: 命令列表
        
        返回:
            (成功与否, 输出)
        """
        try:
            result = subprocess.run(
                command,
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            return True, result.stdout
        except subprocess.CalledProcessError as e:
            return False, e.stderr
    
    def git_status(self):
        """查看Git状态"""
        success, output = self.run_command(["git", "status", "--short"])
        return success, output
    
    def git_add_all(self):
        """添加所有更改"""
        return self.run_command(["git", "add", "."])
    
    def git_commit(self, message=None):
        """
        提交更改
        
        参数:
            message: 提交信息（可选，默认自动生成）
        """
        if message is None:
            # 自动生成提交信息
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            message = f"龙魂系统更新 - {timestamp}"
        
        return self.run_command(["git", "commit", "-m", message])
    
    def git_push(self, remote="origin", branch="main"):
        """
        推送到远程仓库
        
        参数:
            remote: 远程名称（默认origin）
            branch: 分支名称（默认main）
        """
        return self.run_command(["git", "push", remote, branch])
    
    def auto_push(self, commit_message=None):
        """
        自动推送（一键完成：add + commit + push）
        
        参数:
            commit_message: 提交信息（可选）
        
        返回:
            成功与否
        """
        print("🐉 龙魂系统 - Git自动推送")
        print("=" * 50)
        
        # 1. 检查是否是Git仓库
        if not self.check_git_repo():
            print("❌ 错误：当前目录不是Git仓库")
            return False
        
        # 2. 查看状态
        print("📊 检查Git状态...")
        success, status = self.git_status()
        if not success:
            print(f"❌ 获取状态失败: {status}")
            return False
        
        if not status.strip():
            print("✅ 没有需要提交的更改")
            return True
        
        print(f"📝 发现更改:\n{status}")
        
        # 3. 添加所有更改
        print("➕ 添加所有更改...")
        success, output = self.git_add_all()
        if not success:
            print(f"❌ 添加失败: {output}")
            return False
        print("✅ 添加成功")
        
        # 4. 提交
        print("💾 提交更改...")
        success, output = self.git_commit(commit_message)
        if not success:
            print(f"❌ 提交失败: {output}")
            return False
        print("✅ 提交成功")
        
        # 5. 推送
        print("🚀 推送到远程仓库...")
        success, output = self.git_push()
        if not success:
            print(f"❌ 推送失败: {output}")
            return False
        print("✅ 推送成功")
        
        print("=" * 50)
        print("🎉 自动推送完成！")
        return True

# 使用示例
if __name__ == "__main__":
    import sys
    
    # 获取仓库路径（默认当前目录）
    repo_path = sys.argv[1] if len(sys.argv) > 1 else "."
    
    # 获取提交信息（可选）
    commit_msg = sys.argv[2] if len(sys.argv) > 2 else None
    
    # 创建推送工具
    pusher = GitAutoPush(repo_path)
    
    # 执行自动推送
    success = pusher.auto_push(commit_msg)
    
    # 退出码
    sys.exit(0 if success else 1)
```

### 使用方式

```bash
# 方式1: 在仓库目录直接运行
cd ~/Desktop/ai-truth-protocol
python3 ~/longhun-tools/git_auto_push.py

# 方式2: 指定仓库路径
python3 ~/longhun-tools/git_auto_push.py ~/Desktop/ai-truth-protocol

# 方式3: 自定义提交信息
python3 ~/longhun-tools/git_auto_push.py ~/Desktop/ai-truth-protocol "修复DNA生成器bug"

# 方式4: 创建别名（更方便）
# 在 ~/.zshrc 或 ~/.bash_profile 添加：
alias longhun-push='python3 ~/longhun-tools/git_auto_push.py'

# 然后就可以直接用：
cd ~/Desktop/ai-truth-protocol
longhun-push
```

---

## 📱 第五步：社交媒体自动发布（待实现）

### 知乎自动发布（示例设计）

```python
"""
龙魂系统 - 知乎文章自动发布工具
DNA追溯码: #ZHUGEXIN⚡️20260112-ZHIHU-PUBLISHER-001

功能: 将Markdown文章自动发布到知乎
"""

class ZhihuPublisher:
    """知乎发布工具"""
    
    def __init__(self, cookie):
        """
        初始化
        
        参数:
            cookie: 知乎登录cookie
        """
        self.cookie = cookie
        self.api_url = "https://zhuanlan.zhihu.com/api/articles"
    
    def publish_article(self, title, content, tags=None):
        """
        发布文章
        
        参数:
            title: 标题
            content: 内容（Markdown格式）
            tags: 标签列表
        
        返回:
            文章URL
        """
        # TODO: 实现发布逻辑
        # 1. 转换Markdown到知乎格式
        # 2. 调用知乎API
        # 3. 返回文章链接
        pass

# 使用示例
if __name__ == "__main__":
    # 读取文章
    with open("AI避坑指南.md", "r", encoding="utf-8") as f:
        content = f.read()
    
    # 发布到知乎
    publisher = ZhihuPublisher(cookie="你的cookie")
    url = publisher.publish_article(
        title="AI避坑指南：如何识别伪代码",
        content=content,
        tags=["人工智能", "编程", "AI"]
    )
    
    print(f"发布成功: {url}")
```

**注意：** 社交媒体API通常需要：
1. 登录凭证（cookie或token）
2. 了解平台API规则
3. 可能需要人工审核

**建议：**
- 先手动发布，积累经验
- 再逐步实现自动化
- 不着急，慢慢来

---

## 🎯 第六步：工作流程（标准化）

### 日常开发流程

```yaml
步骤1: 打开Mac（龙魂工作站）
  - 只开必要软件：浏览器+终端
  - 打开claude.ai
  - 打开Notion

步骤2: 记录今天要做什么
  - 在Notion写下今天的任务
  - 明确优先级

步骤3: 和Claude协作开发
  - 给Claude需求
  - Claude写代码
  - 您测试
  - 有问题贴回Claude修

步骤4: DeepSeek验证
  - 代码完成后
  - 让DeepSeek挑刺
  - 根据意见修改

步骤5: 保存到本地
  - 代码保存到 ~/longhun-tools/
  - 文档保存到 ~/longhun-docs/

步骤6: 推送到GitHub
  - 运行自动推送脚本
  - python3 ~/longhun-tools/git_auto_push.py

步骤7: 记录到Notion
  - 更新进度
  - 记录遇到的问题
  - 写今天的心得

步骤8: 关机前检查
  - Git状态是否干净
  - 重要文件是否备份
  - 明天任务是否明确
```

### 每周流程（三件事）

```yaml
周日晚上:
  □ 写《龙魂周志》
  □ 回顾本周成果
  □ 规划下周任务
  □ 检验初心

周一到周六:
  □ 用Claude写1个小模块
  □ 用DeepSeek验证
  □ 推送到GitHub
  □ 每天记录进度
```

---

## 🧹 第七步：定期清理（保持纯净）

### 每月清理任务

```yaml
清理缓存:
  □ 清空浏览器缓存
  □ 清空系统缓存
  □ 清空Homebrew缓存

检查软件:
  □ 是否有新装的软件？
  □ 是否真的需要？
  □ 不需要 → 删除

整理文件:
  □ ~/Downloads/ 是否有垃圾？
  □ ~/Desktop/ 是否太乱？
  □ 重要文件是否备份？

审计环境:
  □ 是否偏离了"纯净"原则？
  □ 是否装了不该装的东西？
  □ 及时清理，保持专注
```

### 清理命令

```bash
# 清理Homebrew缓存
brew cleanup

# 清理系统缓存（可选）
sudo rm -rf /Library/Caches/*
sudo rm -rf ~/Library/Caches/*

# 清空下载文件夹（谨慎！）
# rm -rf ~/Downloads/*

# 查看磁盘使用
df -h

# 查看大文件
du -sh ~/* | sort -hr | head -20
```

---

## 💎 第八步：心法（最重要）

### 保持纯净的心法

```yaml
原则1: 少即是多
  - 软件越少越好
  - 功能够用就行
  - 不追求"全能"

原则2: 专注一事
  - 这台Mac只做龙魂系统
  - 不做娱乐
  - 不做其他项目（除非相关）

原则3: 慢工出细活
  - 不着急
  - 每个功能慢慢打磨
  - 质量>速度

原则4: 自己动手
  - 能自己写的插件，不用别人的
  - 哪怕慢一点
  - 都是自己的心血

原则5: 定期审视
  - 每月问自己：
    * 我还守着"纯净"原则吗？
    * 我有没有装不该装的东西？
    * 我的初心变了吗？
```

**这才是工匠精神的Mac！**

---

## 🎯 现在的行动清单

### 今天（如果不累）

```yaml
□ 步骤1: 列出当前Mac上的所有应用
  命令: ls /Applications/ > ~/mac_apps_list.txt
  然后给我看，我们一起决定删哪些

□ 步骤2: 备份重要数据
  - Notion数据（在线，不用担心）
  - 代码仓库（已在GitHub，不用担心）
  - 其他重要文件？

□ 步骤3: 确认删除清单
  - 您决定删哪些
  - 我给删除命令
  - 一个个删，不着急
```

### 明天或本周

```yaml
□ 步骤4: 创建工具目录
  mkdir -p ~/longhun-tools
  mkdir -p ~/longhun-docs

□ 步骤5: 安装DNA生成器
  - 我写完整代码
  - 您保存到 ~/longhun-tools/
  - 测试运行

□ 步骤6: 安装Git自动推送工具
  - 代码已经在上面
  - 您保存测试

□ 步骤7: 设置别名（更方便）
  - 编辑 ~/.zshrc
  - 添加快捷命令
```

---

## 🤝 我的承诺

**老大，您要打造纯净环境，我全力支持：**

```yaml
我会:
  ✅ 帮您分析哪些软件该删
  ✅ 写干净的Python脚本（不依赖复杂库）
  ✅ 每个工具都是A级可运行代码
  ✅ 详细注释，方便您以后改
  ✅ 陪您一个个实现功能

我不会:
  ❌ 建议装一堆软件
  ❌ 推荐复杂工具链
  ❌ 给伪代码
  ❌ 让环境变复杂
```

**咱们一起，把这台Mac打造成"龙魂锻造炉"！** 🔥

---

```
╔═══════════════════════════════════════════════════════════════╗
║  DNA追溯码：#ZHUGEXIN⚡️2026-01-12-MAC-CLEAN-ENV-v1.0        ║
║  理念：纯净、专注、每个工具都是心血之作                      ║
║  目标：打造龙魂系统专用工作站                                ║
╠═══════════════════════════════════════════════════════════════╣
║  删繁就简，回归本质                                          ║
║  少即是多，质量至上                                          ║
║  慢工细活，不急不躁                                          ║
╚═══════════════════════════════════════════════════════════════╝

作者：Lucky (UID9622) + Claude (Anthropic)
状态：方案已完成，等待执行

北辰老兵致敬！🫡
让我们把这台Mac，打造成龙魂锻造炉！🔥
```
