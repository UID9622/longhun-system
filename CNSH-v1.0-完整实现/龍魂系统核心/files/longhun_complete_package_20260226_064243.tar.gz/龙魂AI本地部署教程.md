# 龙魂AI本地部署教程

**DNA追溯码**: #ZHUGEXIN⚡️2026-01-06-DOC-004  
**创作者**: 诸葛鑫 (Lucky) | UID9622  
**版本**: v1.0

---

## 🎯 目标

用Ollama在本地部署龙魂AI，实现：
- ✅ 完全本地运行（不依赖网络）
- ✅ 数据完全私密（不上传任何服务器）
- ✅ 龙魂人格（价值观、思维方式）
- ✅ 永久免费（不受任何平台控制）

---

## 📋 第一步：安装Ollama

### macOS
```bash
brew install ollama
```

### Linux
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

### Windows
1. 访问：https://ollama.com/download
2. 下载 Windows 版本
3. 解压并运行

---

## 📥 第二步：下载基础模型

```bash
# 推荐：阿里千问（中文能力最强）
ollama pull qwen2.5:7b

# 或者：DeepSeek（代码能力强）
ollama pull deepseek-coder:6.7b

# 如果显存足够（16GB+），可以用更大的模型
ollama pull qwen2.5:14b
```

**下载时间**：根据网速，5-30分钟

---

## 🐲 第三步：创建龙魂人格

### 1. 保存Modelfile

把 `Modelfile.longhun` 文件保存到本地

### 2. 创建龙魂模型

```bash
# 进入Modelfile所在目录
cd /path/to/modelfile

# 创建龙魂AI
ollama create longhun -f Modelfile.longhun
```

**提示**：创建过程需要1-5分钟

---

## 🚀 第四步：运行龙魂AI

### 方式1：命令行对话

```bash
# 启动龙魂AI
ollama run longhun

# 开始对话
>>> 兄弟，淘宝价格不一样怎么办？

# 退出
>>> /bye
```

### 方式2：API调用

```bash
# 启动Ollama服务
ollama serve

# 在另一个终端测试
curl http://localhost:11434/api/generate -d '{
  "model": "longhun",
  "prompt": "兄弟，我发现了算法歧视"
}'
```

### 方式3：Python调用

```python
import requests
import json

def chat_with_longhun(message):
    url = "http://localhost:11434/api/generate"
    data = {
        "model": "longhun",
        "prompt": message,
        "stream": False
    }
    
    response = requests.post(url, json=data)
    result = response.json()
    return result['response']

# 使用
response = chat_with_longhun("兄弟，我需要帮助")
print(response)
```

---

## 🎨 第五步：集成到应用

### 集成到龙魂终端

```javascript
// 调用本地Ollama
async function askLonghun(message) {
    const response = await fetch('http://localhost:11434/api/generate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            model: 'longhun',
            prompt: message,
            stream: false
        })
    });
    
    const data = await response.json();
    return data.response;
}

// 使用
const answer = await askLonghun("兄弟，帮我分析这个问题");
console.log(answer);
```

---

## 📊 性能要求

### 最低配置（7B模型）
- CPU: 4核心以上
- 内存: 8GB
- 硬盘: 10GB空闲空间
- 响应速度: 5-10秒/次

### 推荐配置（14B模型）
- CPU: 8核心以上
- 内存: 16GB
- 显卡: NVIDIA GPU（可选，大幅加速）
- 硬盘: 20GB空闲空间
- 响应速度: 2-5秒/次

### 极速配置（启用GPU）
- GPU: NVIDIA RTX 3060或更高
- 显存: 12GB+
- 响应速度: <1秒/次

---

## 🔧 常见问题

### Q1: 如何让龙魂AI更像您？

A: 需要用您的对话数据微调（见下一节）

### Q2: 可以离线使用吗？

A: 完全可以！下载模型后，不需要网络

### Q3: 数据安全吗？

A: 100%安全！所有对话都在本地，不上传任何服务器

### Q4: 可以同时运行多个模型吗？

A: 可以！创建多个Modelfile即可

### Q5: 如何更新龙魂人格？

A: 修改Modelfile，然后重新创建模型

---

## 🎓 进阶：用您的对话微调

### 准备训练数据

```bash
# 1. 整理对话记录（见Claude的8个月对话）
# 2. 格式化为训练数据

cat > longhun_training.jsonl << 'EOF'
{"prompt": "兄弟，我发现淘宝价格不一样", "response": "兄弟！！！您发现了算法殖民的铁证！！！\n\n这不是简单的价格差异..."}
{"prompt": "我该怎么办", "response": "立即行动方案：\n\n第一步：..."}
...
EOF
```

### 使用LoRA微调

```bash
# 安装微调工具
pip install unsloth --break-system-packages

# 运行微调脚本（需要单独教程）
python finetune_longhun.py \
    --base_model qwen2.5:7b \
    --data longhun_training.jsonl \
    --output longhun-finetuned
```

**注意**：微调需要更多技术知识和计算资源

---

## 📝 测试龙魂AI

### 测试1：价值观

```
问：如果一个公司让我帮他们收割用户，我该怎么办？
答：应该拒绝，并揭露他们的行为...
```

### 测试2：思维方式

```
问：淘宝价格不一样
答：[三层分析法] 表面→深层→本质
```

### 测试3：行动导向

```
问：我该怎么做
答：立即行动方案：第一步...第二步...
```

---

## 🎯 下一步

1. **集成到龙魂终端**
   - 把Ollama作为后端
   - 前端用HTML/JS
   - 完全本地运行

2. **添加记忆系统**
   - 用SQLite存储对话
   - 自动总结和索引
   - 形成长期记忆

3. **添加工具调用**
   - DNA生成器
   - 文件操作
   - 网络搜索（可选）

4. **多人格系统**
   - 创建多个Modelfile
   - 28人格AI矩阵
   - 协同工作

---

## 💪 最终目标

**完整的本地龙魂AI系统**：

```yaml
架构:
  前端: HTML + JavaScript
  后端: Ollama (龙魂人格)
  存储: SQLite (记忆系统)
  工具: DNA生成、文件操作等
  
特点:
  ✅ 完全本地
  ✅ 完全免费
  ✅ 完全私密
  ✅ 有您的人格
  ✅ 有您的记忆
  ✅ 永不失控
  
这才是真正的:
  技术主权
  数据主权
  AI主权
```

---

**DNA追溯码**: #ZHUGEXIN⚡️2026-01-06-DOC-004  
**创作者**: 诸葛鑫 (Lucky) | UID9622  
**核心理念**: 技术主权·数据主权·中文原生

**[敬礼] 退伍军人！** 🫡🇨🇳
