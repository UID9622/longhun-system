# 🔐 UID9622本地终端加密工具 v4.0

[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.6%2B-green.svg)](https://www.python.org/)
[![DNA](https://img.shields.io/badge/DNA-ZHUGEXIN⚡️-red.svg)](#)
[![GPG](https://img.shields.io/badge/GPG-A2D0092C...-orange.svg)](#)

> **让你的Python代码安全加密，防止源码泄露，保护核心算法**

```
╔═══════════════════════════════════════════════════════════════╗
║  🐉 龙魂系统 | UID9622                                        ║
╠═══════════════════════════════════════════════════════════════╣
║  📦 名称：UID9622本地终端加密工具                             ║
║  📌 版本：v4.0                                                ║
║  🧬 DNA：#ZHUGEXIN⚡️2026-01-09-CRYPTO-TOOL-v4.0              ║
║  🔐 GPG：A2D0092CEE2E5BA87035600924C3704A8CC26D5F            ║
║  👤 创建：Lucky·UID9622                                       ║
║  🤝 协作：诸葛亮🎯(架构) + 文心💙(实现) + 宝宝🐱(测试)       ║
╚═══════════════════════════════════════════════════════════════╝
```

---

## 📋 目录

- [功能特性](#-功能特性)
- [快速开始](#-快速开始)
- [安装方法](#-安装方法)
- [使用指南](#-使用指南)
- [工作原理](#-工作原理)
- [使用示例](#-使用示例)
- [常见问题](#-常见问题)
- [安全说明](#-安全说明)
- [更新日志](#-更新日志)
- [许可证](#-许可证)
- [联系方式](#-联系方式)

---

## ✨ 功能特性

### 🔒 核心功能

- **四层加密保护**：字节码编译 → Zlib压缩 → XOR加密 → Base64编码
- **单文件加密**：快速加密单个Python文件
- **批量加密**：一键加密整个文件夹的所有Python文件
- **功能测试**：验证加密后的文件是否正常运行
- **文件解密**：使用密钥恢复加密文件（需要密钥文件）
- **历史记录**：完整的加密历史追踪

### 🛡️ 安全特性

- **SHA-512密钥**：使用SHA-512哈希生成强密钥
- **GPG验证**：集成GPG签名验证机制
- **DNA追溯**：每个加密包都有唯一的DNA追溯码
- **熔断保护**：签名失效时自动熔断
- **本地运行**：完全在本地运行，不联网

### 📦 生成文件

加密一个文件后，自动生成3个文件：

1. `xxx_encrypted.py` - 加密后的文件（可分发）
2. `xxx_key.txt` - 解密密钥（私密保存）
3. `xxx_demo.py` - 使用示例（快速上手）

---

## 🚀 快速开始

### 最简单的使用方式

```bash
# 1. 下载工具
git clone https://github.com/uid9622/longhun-crypto.git
cd longhun-crypto

# 2. 运行工具
python UID9622加密工具-v4.0-龙魂规范版.py

# 3. 选择功能
# 输入 1 → 加密单个文件
# 输入文件路径 → 完成！
```

### 10秒加密示例

```bash
$ python UID9622加密工具-v4.0-龙魂规范版.py

📋 请选择操作：
  1️⃣  加密单个文件

请选择 > 1

请输入文件路径: my_algorithm.py

🔐 开始加密: my_algorithm.py
🔑 密钥: a3d5f8b2...
🔒 第1层：编译成字节码...
🔒 第2层：压缩...
🔒 第3层：XOR加密...
🔒 第4层：Base64编码...

✅ 加密完成！

生成的文件：
  1. my_algorithm_encrypted.py  ← 加密后的文件（给别人用）
  2. my_algorithm_key.txt       ← 解密密钥（你保存）
  3. my_algorithm_demo.py       ← 使用示例
```

---

## 📥 安装方法

### 方法一：直接下载（推荐）

```bash
# 下载项目
git clone https://github.com/uid9622/longhun-crypto.git
cd longhun-crypto

# 直接运行（无需安装依赖）
python UID9622加密工具-v4.0-龙魂规范版.py
```

### 方法二：下载单个文件

```bash
# 下载加密工具
wget https://github.com/uid9622/longhun-crypto/raw/main/UID9622加密工具-v4.0-龙魂规范版.py

# 运行
python UID9622加密工具-v4.0-龙魂规范版.py
```

### 系统要求

- **Python版本**：Python 3.6+
- **操作系统**：Windows / macOS / Linux
- **依赖库**：无（使用Python标准库）

---

## 📖 使用指南

### 1️⃣ 加密单个文件

```bash
python UID9622加密工具-v4.0-龙魂规范版.py
选择 > 1
输入文件路径: /path/to/your/file.py
✅ 加密完成！
```

### 2️⃣ 批量加密文件夹

```bash
python UID9622加密工具-v4.0-龙魂规范版.py
选择 > 2
输入文件夹路径: /path/to/your/project
📊 找到 15 个Python文件
是否全部加密？(y/n): y
✅ 成功: 15 个
```

### 3️⃣ 测试加密文件

```bash
python UID9622加密工具-v4.0-龙魂规范版.py
选择 > 3
输入加密文件路径: your_file_encrypted.py
✅ 测试通过！
```

### 4️⃣ 解密文件

```bash
python UID9622加密工具-v4.0-龙魂规范版.py
选择 > 4
1. 加密文件路径: your_file_encrypted.py
2. 密钥文件路径: your_file_key.txt
🔓 解密完成！
```

---

## 🔧 工作原理

### 加密流程（四层加密）

```
源代码 (source.py)
    ↓
第1层：编译成字节码 (marshal)
    ↓
第2层：压缩 (zlib, level=9)
    ↓
第3层：XOR加密 (密钥: SHA-512)
    ↓
第4层：Base64编码
    ↓
加密文件 (source_encrypted.py)
```

### 密钥生成

```python
密钥源 = f"UID9622-{文件路径}-{时间戳}-{随机数据}-{GPG指纹}"
密钥 = hashlib.sha512(密钥源.encode()).hexdigest()
# 生成128位十六进制字符串（512位哈希）
```

---

## 💡 使用示例

### 示例1：加密核心算法

```python
# 1. 加密文件
python UID9622加密工具-v4.0-龙魂规范版.py
选择 > 1
输入文件: my_algorithm.py

# 2. 客户使用
import my_algorithm_encrypted as algo
result = algo.core_function(data)  # 功能完全正常！
```

---

## ❓ 常见问题

### Q1: 加密后的文件安全吗？

**A:** 采用四层加密，安全性高。可防止普通用户查看源码和简单逆向工程。

### Q2: 加密后功能会受影响吗？

**A:** 不会！加密后的文件功能完全正常。

### Q3: 密钥丢了怎么办？

**A:** 密钥丢失后**无法恢复源代码**！请务必备份密钥和原始源码。

### Q4: 支持哪些Python版本？

**A:** Python 3.6+

---

## 🛡️ 安全说明

### 威胁模型

**本工具可以防护：**
- ✅ 普通用户查看源码
- ✅ 简单的字符串搜索
- ✅ 初级的逆向工程

**本工具无法防护：**
- ❌ 专业的破解攻击
- ❌ 内存dump分析
- ❌ 动态调试

### 责任声明

```
⚠️  重要声明

本工具提供代码加密保护，但不保证绝对安全。

使用本工具即表示您已知晓：
1. 没有绝对安全的加密方案
2. 专业破解者可能解密您的代码
3. 作者不对因使用本工具产生的任何后果负责
```

---

## 📝 更新日志

### v4.0 (2026-01-09) - 龙魂规范版

**新增功能：**
- ✅ 添加完整龙魂头部（DNA追溯码+GPG签名）
- ✅ 补全文件夹批量加密功能
- ✅ 补全加密文件测试功能
- ✅ 补全文件解密功能
- ✅ 添加熔断机制

---

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

---

## 📧 联系方式

**作者**：Lucky (UID9622)

- 📧 **邮箱**：uid9622@petalmail.com
- 🐙 **GitHub**：https://github.com/uid9622
- 🔐 **GPG指纹**：A2D0092CEE2E5BA87035600924C3704A8CC26D5F

---

**DNA追溯码**：#ZHUGEXIN⚡️2026-01-09-CRYPTO-TOOL-v4.0  
**GPG指纹**：A2D0092CEE2E5BA87035600924C3704A8CC26D5F  

---

<div align="center">

**如果这个项目对你有帮助，请给一个⭐Star！**

Made with ❤️ by Lucky (UID9622) | 🐉 龙魂系统

</div>
