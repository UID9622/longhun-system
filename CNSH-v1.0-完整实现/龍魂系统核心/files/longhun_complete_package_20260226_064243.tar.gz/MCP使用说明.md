# 🐉 龙魂MCP服务器使用说明

**DNA追溯码**：#龙芯⚡️2026-02-21-MCP使用说明-v1.0  
**确认码**：#CONFIRM🌌9622-ONLY-ONCE🧬LONGHUN-MCP-DOC-001

**作者**：Lucky (UID9622)  
**协作**：Claude (Anthropic)  
**服务器**：华为云 119.13.90.27:8080

---

## 📚 目录

1. [什么是MCP](#什么是mcp)
2. [快速开始](#快速开始)
3. [部署步骤](#部署步骤)
4. [在Claude中配置](#在claude中配置)
5. [可用工具](#可用工具)
6. [使用示例](#使用示例)
7. [故障排除](#故障排除)

---

## 什么是MCP

**MCP = Model Context Protocol（模型上下文协议）**

```yaml
传统方式：
  Claude → 调用 → 第三方API（Google/Notion/微软）
  
  问题：
    ❌ 数据经过第三方
    ❌ 逻辑被第三方控制
    ❌ 没有数据主权

MCP方式：
  Claude → 直接调用 → 你自己的服务器（119.13.90.27）
  
  优势：
    ✅ 数据在你的华为云上
    ✅ 逻辑你自己写
    ✅ 完全可控
    ✅ 数据主权
```

**龙魂MCP的核心理念：**
- 数据主权在中国（华为云）
- 自己说了算（自己的服务器）
- 光明磊落（所有对话有痕迹）
- 为人民服务（技术平权）

---

## 快速开始

### 1. 下载文件

你需要这些文件：
- `longhun_mcp_server.py` - MCP服务器主程序
- `deploy_mcp.sh` - 一键部署脚本
- `test_mcp.py` - 测试脚本
- `mcp_config.json` - Claude配置文件

### 2. 上传到服务器

```bash
# 连接到你的华为云服务器
ssh root@119.13.90.27

# 上传文件
scp *.py root@119.13.90.27:/root/
scp *.sh root@119.13.90.27:/root/
scp *.json root@119.13.90.27:/root/
```

### 3. 一键部署

```bash
# 在服务器上运行
cd /root
chmod +x deploy_mcp.sh
sudo bash deploy_mcp.sh
```

部署脚本会自动完成：
- ✅ 创建目录结构
- ✅ 安装依赖
- ✅ 初始化数据库
- ✅ 配置systemd服务
- ✅ 开放防火墙端口
- ✅ 启动MCP服务器

### 4. 验证部署

```bash
# 测试服务器
python3 test_mcp.py

# 查看服务状态
systemctl status longhun-mcp

# 查看日志
tail -f /home/longhun/logs/mcp_server.log
```

---

## 部署步骤

### 方式1：一键部署（推荐）

```bash
sudo bash deploy_mcp.sh
```

### 方式2：手动部署

#### 步骤1：创建目录

```bash
mkdir -p /home/longhun/{mcp,data,logs,scripts,backup}
```

#### 步骤2：安装依赖

```bash
pip3 install flask flask-cors
```

#### 步骤3：复制文件

```bash
cp longhun_mcp_server.py /home/longhun/mcp/
chmod +x /home/longhun/mcp/longhun_mcp_server.py
```

#### 步骤4：创建systemd服务

```bash
cat > /etc/systemd/system/longhun-mcp.service << 'EOF'
[Unit]
Description=龙魂MCP服务器
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/home/longhun/mcp
ExecStart=/usr/bin/python3 /home/longhun/mcp/longhun_mcp_server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl start longhun-mcp
systemctl enable longhun-mcp
```

#### 步骤5：配置防火墙

```bash
# firewalld
firewall-cmd --permanent --add-port=8080/tcp
firewall-cmd --reload

# 或者 ufw
ufw allow 8080/tcp
```

---

## 在Claude中配置

### 步骤1：打开Claude设置

1. 进入 Claude.ai
2. 点击右上角设置图标
3. 选择 "Integrations" 或 "集成"

### 步骤2：添加自定义MCP

1. 点击 "Add Custom MCP Server" 或 "添加自定义MCP服务器"
2. 填写以下信息：

```yaml
名称：龙魂本地系统

描述：连接华为云服务器的龙魂数字主权系统

服务器URL：http://119.13.90.27:8080

API密钥：#CONFIRM🌌9622-ONLY-ONCE🧬LONGHUN-MCP-001
```

### 步骤3：导入工具定义

复制 `mcp_config.json` 的内容，粘贴到工具定义区域。

或者手动添加每个工具（参见下一节）。

### 步骤4：测试连接

点击 "Test Connection" 或 "测试连接"

如果显示 ✅ Connected，说明配置成功！

---

## 可用工具

### 1. query_dna - 查询DNA追溯码

**功能**：查询DNA码的完整信息

**参数**：
- `dna_code` (必需) - DNA追溯码

**示例**：
```
用龙魂本地系统查询DNA码 #龙芯⚡️2026-02-21-MCP服务器-v1.0
```

---

### 2. create_dna - 创建DNA追溯码

**功能**：为新项目创建DNA码

**参数**：
- `project_name` (必需) - 项目名称
- `uid` (可选) - 用户ID，默认9622

**示例**：
```
用龙魂本地系统创建一个DNA码，项目名称是"新论文"
```

---

### 3. sync_notion - 同步Notion

**功能**：手动触发Notion数据同步

**参数**：无

**示例**：
```
用龙魂本地系统同步Notion
```

---

### 4. run_audit - 运行三色审计

**功能**：对内容进行审计分类

**参数**：
- `target` (必需) - 审计目标

**返回**：
- 🟢 绿色 - 通过
- 🟡 黄色 - 警告
- 🔴 红色 - 严重

**示例**：
```
用龙魂本地系统审计这段文本："..."
```

---

### 5. get_system_status - 系统状态

**功能**：获取龙魂系统运行状态

**参数**：无

**返回**：
- DNA记录数量
- 用户数量
- 最新DNA码
- 服务器状态

**示例**：
```
用龙魂本地系统查看系统状态
```

---

### 6. store_memory - 存储记忆

**功能**：存储记忆到数字永生系统

**参数**：
- `uid` (可选) - 用户ID
- `content` (必需) - 记忆内容
- `category` (可选) - 分类

**示例**：
```
用龙魂本地系统存储记忆："今天完成了MCP服务器的搭建"
```

---

### 7. trigger_backup - 触发备份

**功能**：触发系统完整备份

**参数**：无

**示例**：
```
用龙魂本地系统触发备份
```

---

## 使用示例

### 示例1：日常使用

**你对Claude说：**
```
用龙魂本地系统查看一下系统状态
```

**Claude会：**
1. 调用你的MCP服务器
2. 获取系统状态
3. 告诉你：
   - DNA记录：xxx条
   - 用户数：xxx人
   - 最新DNA码：xxx
   - 服务器运行正常 ✅

---

### 示例2：创建新项目

**你对Claude说：**
```
帮我创建一个新项目的DNA码，项目名称是"龙魂移动端App"
```

**Claude会：**
1. 调用 create_dna
2. 传入项目名称
3. 返回新的DNA码：`#龙芯⚡️2026-02-21-龙魂移动端App-9622`

---

### 示例3：审计内容

**你对Claude说：**
```
用龙魂本地系统审计一下这段文字："智谱清言是骗子公司，盗走了我的逻辑"
```

**Claude会：**
1. 调用 run_audit
2. 返回审计结果：
   - 颜色：🟡 黄色
   - 状态：警告
   - 原因：涉及争议性陈述

---

### 示例4：存储对话记忆

**你对Claude说：**
```
把我们今天关于MCP的讨论存储到记忆系统
```

**Claude会：**
1. 提取对话要点
2. 调用 store_memory
3. 存储到你的数据库
4. 返回存储ID和哈希值

---

## 故障排除

### 问题1：连接失败

**症状**：Claude显示 "Connection Failed"

**排查步骤**：

```bash
# 1. 检查服务是否运行
systemctl status longhun-mcp

# 2. 检查端口是否监听
netstat -tuln | grep 8080

# 3. 检查防火墙
firewall-cmd --list-ports  # firewalld
ufw status                  # ufw

# 4. 手动测试
curl http://localhost:8080/
```

**解决方法**：
- 如果服务未运行：`systemctl start longhun-mcp`
- 如果端口未开放：`firewall-cmd --add-port=8080/tcp --permanent && firewall-cmd --reload`

---

### 问题2：工具调用失败

**症状**：Claude调用工具后报错

**排查步骤**：

```bash
# 查看服务器日志
tail -f /home/longhun/logs/mcp_server.log

# 查看systemd日志
journalctl -u longhun-mcp -f
```

**常见错误**：
- `数据库文件不存在` → 运行部署脚本初始化数据库
- `脚本路径错误` → 检查 CONFIG 中的路径配置
- `权限不足` → 确保服务以root运行

---

### 问题3：数据库错误

**症状**：数据库操作失败

**解决方法**：

```bash
# 备份当前数据库
cp /home/longhun/data/longhun.db /home/longhun/backup/longhun_$(date +%Y%m%d).db

# 重新初始化
cd /home/longhun/mcp
python3 longhun_mcp_server.py

# 或者手动创建表
sqlite3 /home/longhun/data/longhun.db < schema.sql
```

---

### 问题4：性能问题

**症状**：响应缓慢

**优化方法**：

```bash
# 1. 检查系统资源
top
df -h

# 2. 优化数据库
sqlite3 /home/longhun/data/longhun.db "VACUUM;"

# 3. 重启服务
systemctl restart longhun-mcp

# 4. 查看日志找瓶颈
tail -f /home/longhun/logs/mcp_server.log
```

---

## 常用命令

```bash
# 查看服务状态
systemctl status longhun-mcp

# 启动服务
systemctl start longhun-mcp

# 停止服务
systemctl stop longhun-mcp

# 重启服务
systemctl restart longhun-mcp

# 查看日志（实时）
tail -f /home/longhun/logs/mcp_server.log

# 查看systemd日志
journalctl -u longhun-mcp -f

# 测试连接
curl http://localhost:8080/

# 运行测试脚本
python3 test_mcp.py

# 手动备份数据库
cp /home/longhun/data/longhun.db /home/longhun/backup/longhun_$(date +%Y%m%d).db
```

---

## 安全建议

### 1. 使用HTTPS

```bash
# 安装certbot
yum install certbot python3-certbot-nginx

# 申请证书
certbot --nginx -d 119.13.90.27
```

### 2. API密钥验证

在MCP服务器中加入：

```python
@app.before_request
def verify_api_key():
    api_key = request.headers.get('X-API-Key')
    if api_key != CONFIG['api_key']:
        return jsonify({'error': 'Invalid API key'}), 401
```

### 3. IP白名单

```python
ALLOWED_IPS = ['你的IP地址']

@app.before_request
def check_ip():
    if request.remote_addr not in ALLOWED_IPS:
        return jsonify({'error': 'Forbidden'}), 403
```

### 4. 日志审计

定期检查日志：

```bash
# 查看访问记录
grep "POST\|GET" /home/longhun/logs/mcp_server.log

# 查看错误
grep "ERROR" /home/longhun/logs/mcp_server.log
```

---

## 技术支持

**遇到问题？**

1. 查看日志：`tail -f /home/longhun/logs/mcp_server.log`
2. 运行测试：`python3 test_mcp.py`
3. 检查服务：`systemctl status longhun-mcp`

**联系方式**：
- 邮箱：uid9622@petalmail.com
- DNA追溯码：#龙芯⚡️2026-02-21-MCP使用说明-v1.0

---

## 附录：完整配置示例

### mcp_config.json

```json
{
  "mcpServers": {
    "longhun-system": {
      "name": "龙魂本地系统",
      "url": "http://119.13.90.27:8080",
      "apiKey": "#CONFIRM🌌9622-ONLY-ONCE🧬LONGHUN-MCP-001",
      "tools": [...]
    }
  }
}
```

详细工具定义请参考 `mcp_config.json` 文件。

---

**DNA追溯码**：#龙芯⚡️2026-02-21-MCP使用说明-v1.0  
**确认码**：#CONFIRM🌌9622-ONLY-ONCE🧬LONGHUN-MCP-DOC-001

**🫡 敬礼！老兵！**  
**🐉 龙魂·为人民服务！**
