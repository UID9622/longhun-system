# 🔧 CNSH编译器·补充优化包

**DNA追溯码：** `#ZHUGEXIN⚡️2025-12-31-CNSH语言-优化包-V1.0`

**根据CodeBuddy审计建议，补充以下优化：**

---

## 📄 补充1：错误恢复机制

**文件名：** `error-recovery.js`

**说明：** 让编译器遇到错误后能继续解析，找出更多问题

```javascript
// 错误恢复机制
// DNA追溯码：#ZHUGEXIN⚡️2025-12-31-CNSH语言-错误恢复-V1.0

class ErrorRecovery {
  constructor() {
    this.errors = [];
    this.warnings = [];
  }

  // 记录错误但继续
  recordError(error) {
    this.errors.push({
      type: 'error',
      message: error.message,
      line: error.line || 'unknown',
      column: error.column || 'unknown',
      timestamp: new Date().toISOString()
    });
  }

  // 记录警告
  recordWarning(warning) {
    this.warnings.push({
      type: 'warning',
      message: warning.message,
      line: warning.line || 'unknown',
      column: warning.column || 'unknown',
      timestamp: new Date().toISOString()
    });
  }

  // 尝试恢复到下一个语句
  recoverToNextStatement(parser) {
    // 跳过当前错误，找到下一个语句开始的地方
    const syncTokens = ['SEMICOLON', 'RBRACE', 'KEYWORD'];
    
    while (parser.current().type !== 'EOF') {
      if (syncTokens.includes(parser.current().type)) {
        if (parser.current().type === 'SEMICOLON') {
          parser.advance(); // 跳过分号
        }
        break;
      }
      parser.advance();
    }
  }

  // 生成错误报告
  generateReport() {
    let report = '\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n';
    report += '   📋 编译报告\n';
    report += '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n';

    if (this.errors.length === 0 && this.warnings.length === 0) {
      report += '✅ 没有错误或警告\n';
    } else {
      if (this.errors.length > 0) {
        report += `❌ 发现 ${this.errors.length} 个错误：\n\n`;
        this.errors.forEach((err, idx) => {
          report += `${idx + 1}. 行${err.line}列${err.column}：${err.message}\n`;
        });
        report += '\n';
      }

      if (this.warnings.length > 0) {
        report += `⚠️  发现 ${this.warnings.length} 个警告：\n\n`;
        this.warnings.forEach((warn, idx) => {
          report += `${idx + 1}. 行${warn.line}列${warn.column}：${warn.message}\n`;
        });
      }
    }

    report += '\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n';
    return report;
  }

  // 判断是否有致命错误
  hasFatalErrors() {
    return this.errors.length > 0;
  }
}

// 在Parser类中集成错误恢复
// 修改parseStatement方法：
/*
parseStatement() {
  try {
    const token = this.current();
    // ... 原有逻辑
  } catch (error) {
    // 记录错误
    this.errorRecovery.recordError({
      message: error.message,
      line: this.current().line,
      column: this.current().column
    });
    
    // 尝试恢复
    this.errorRecovery.recoverToNextStatement(this);
    
    // 返回null继续解析
    return null;
  }
}
*/

module.exports = { ErrorRecovery };
```

---

## 📄 补充2：调试信息生成器

**文件名：** `debug-info.js`

**说明：** 在生成的C代码中添加行号注释，方便调试

```javascript
// 调试信息生成器
// DNA追溯码：#ZHUGEXIN⚡️2025-12-31-CNSH语言-调试信息-V1.0

class DebugInfoGenerator {
  constructor(enableDebug = true) {
    this.enableDebug = enableDebug;
    this.sourceMap = new Map(); // CNSH行号 -> C行号映射
  }

  // 生成行号注释
  generateLineComment(cnshLine, cnshCode) {
    if (!this.enableDebug) return '';
    
    return `/* CNSH:${cnshLine} | ${cnshCode.trim().substring(0, 40)}... */`;
  }

  // 生成DNA追溯注释
  generateDNAComment(dnaCode) {
    return `/* DNA追溯码：${dnaCode} */`;
  }

  // 生成函数入口调试信息
  generateFunctionEntryDebug(functionName, cnshLine) {
    if (!this.enableDebug) return '';
    
    return `    printf("[DEBUG] 进入函数: ${functionName} (CNSH行号:${cnshLine})\\n");`;
  }

  // 生成变量声明调试信息
  generateVarDeclDebug(varName, varValue, cnshLine) {
    if (!this.enableDebug) return '';
    
    return `    printf("[DEBUG] 变量声明: ${varName} = %d (CNSH行号:${cnshLine})\\n", (int)${varValue});`;
  }

  // 在CCodeGenerator中集成
  // 修改emit方法：
  /*
  emit(code, cnshLine = null, cnshCode = null) {
    const indentStr = '    '.repeat(this.indent);
    
    if (this.debugInfo && cnshLine) {
      const comment = this.debugInfo.generateLineComment(cnshLine, cnshCode);
      this.output.push(`${indentStr}${comment}`);
    }
    
    this.output.push(indentStr + code);
  }
  */
}

module.exports = { DebugInfoGenerator };
```

---

## 📄 补充3：常量折叠优化器

**文件名：** `const-folding.js`

**说明：** 编译时计算常量表达式，优化生成的代码

```javascript
// 常量折叠优化器
// DNA追溯码：#ZHUGEXIN⚡️2025-12-31-CNSH语言-常量折叠-V1.0

class ConstantFolder {
  constructor() {
    this.optimizationCount = 0;
  }

  // 优化AST节点
  optimize(node) {
    if (!node) return node;

    switch (node.type) {
      case 'BinaryOp':
        return this.foldBinaryOp(node);
      case 'UnaryOp':
        return this.foldUnaryOp(node);
      case 'Program':
        node.statements = node.statements.map(stmt => this.optimize(stmt));
        return node;
      case 'FunctionDeclaration':
        node.body = node.body.map(stmt => this.optimize(stmt));
        return node;
      case 'IfStatement':
        node.thenBody = node.thenBody.map(stmt => this.optimize(stmt));
        if (node.elseBody) {
          node.elseBody = node.elseBody.map(stmt => this.optimize(stmt));
        }
        return node;
      default:
        return node;
    }
  }

  // 折叠二元运算
  foldBinaryOp(node) {
    // 递归优化左右子节点
    node.left = this.optimize(node.left);
    node.right = this.optimize(node.right);

    // 如果两边都是常量，计算结果
    if (node.left.type === 'Number' && node.right.type === 'Number') {
      const leftVal = parseFloat(node.left.value);
      const rightVal = parseFloat(node.right.value);
      let result;

      switch (node.op) {
        case '+':
          result = leftVal + rightVal;
          break;
        case '-':
          result = leftVal - rightVal;
          break;
        case '*':
          result = leftVal * rightVal;
          break;
        case '/':
          result = leftVal / rightVal;
          break;
        case '%':
          result = leftVal % rightVal;
          break;
        case '>':
        case '<':
        case '>=':
        case '<=':
        case '==':
        case '!=':
          // 比较运算返回布尔值
          const boolResult = this.evaluateComparison(leftVal, rightVal, node.op);
          this.optimizationCount++;
          return {
            type: 'Boolean',
            value: boolResult
          };
        default:
          return node;
      }

      this.optimizationCount++;
      return {
        type: 'Number',
        value: result.toString()
      };
    }

    return node;
  }

  // 折叠一元运算
  foldUnaryOp(node) {
    node.operand = this.optimize(node.operand);

    if (node.operand.type === 'Number') {
      const val = parseFloat(node.operand.value);
      let result;

      switch (node.op) {
        case '-':
          result = -val;
          break;
        case '!':
          result = !val;
          this.optimizationCount++;
          return {
            type: 'Boolean',
            value: result
          };
        default:
          return node;
      }

      this.optimizationCount++;
      return {
        type: 'Number',
        value: result.toString()
      };
    }

    return node;
  }

  // 计算比较表达式
  evaluateComparison(left, right, op) {
    switch (op) {
      case '>': return left > right;
      case '<': return left < right;
      case '>=': return left >= right;
      case '<=': return left <= right;
      case '==': return left === right;
      case '!=': return left !== right;
      default: return false;
    }
  }

  // 获取优化统计
  getStats() {
    return {
      optimizationCount: this.optimizationCount,
      message: `已优化 ${this.optimizationCount} 个常量表达式`
    };
  }
}

// 使用示例：
// const folder = new ConstantFolder();
// const optimizedAST = folder.optimize(ast);
// console.log(folder.getStats().message);

module.exports = { ConstantFolder };
```

---

## 📄 补充4：.gitignore文件

**文件名：** `.gitignore`

**说明：** 防止不必要的文件上传到Gitee

```gitignore
# CNSH编译器·Gitignore配置
# DNA追溯码：#ZHUGEXIN⚡️2025-12-31-CNSH语言-Gitignore

# Node.js
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# 编译输出
*.c
*.o
*.out
*.exe
*.generated.js
hello
my_program

# 系统文件
.DS_Store
Thumbs.db
*.swp
*.swo
*~

# IDE配置
.vscode/
.idea/
*.sublime-*

# 临时文件
tmp/
temp/
*.tmp

# 日志文件
*.log

# 但保留示例文件
!hello.cnsh
!README.md
!cnsh-compiler.js
```

---

## 📄 补充5：自动化测试脚本

**文件名：** `test-cnsh.sh`

**说明：** 一键测试编译器所有功能

```bash
#!/bin/bash
# CNSH编译器自动化测试脚本
# DNA追溯码：#ZHUGEXIN⚡️2025-12-31-CNSH语言-测试脚本

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "   🧪 CNSH编译器自动化测试"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# 测试计数
TESTS_PASSED=0
TESTS_FAILED=0

# 测试1：基本编译
echo "📝 测试1：编译hello.cnsh..."
if node cnsh-compiler.js hello.cnsh > /dev/null 2>&1; then
    echo "   ✅ 编译成功"
    ((TESTS_PASSED++))
else
    echo "   ❌ 编译失败"
    ((TESTS_FAILED++))
fi

# 测试2：生成C代码
echo "📝 测试2：检查生成的C代码..."
if [ -f "hello.c" ]; then
    echo "   ✅ C代码已生成"
    ((TESTS_PASSED++))
else
    echo "   ❌ C代码未生成"
    ((TESTS_FAILED++))
fi

# 测试3：C代码编译
echo "📝 测试3：编译C代码..."
if gcc hello.c -o hello > /dev/null 2>&1; then
    echo "   ✅ C代码编译成功"
    ((TESTS_PASSED++))
else
    echo "   ❌ C代码编译失败"
    ((TESTS_FAILED++))
fi

# 测试4：运行可执行文件
echo "📝 测试4：运行可执行文件..."
if ./hello > /tmp/cnsh_output.txt 2>&1; then
    echo "   ✅ 程序运行成功"
    ((TESTS_PASSED++))
    
    # 检查输出
    if grep -q "CNSH语言" /tmp/cnsh_output.txt; then
        echo "   ✅ 输出内容正确"
        ((TESTS_PASSED++))
    else
        echo "   ❌ 输出内容错误"
        ((TESTS_FAILED++))
    fi
else
    echo "   ❌ 程序运行失败"
    ((TESTS_FAILED++))
fi

# 测试5：三色审计
echo "📝 测试5：三色审计功能..."
cat > /tmp/test-audit.cnsh << 'EOF'
函数 主函数() 返回类型 整数 {
  打印「正常内容」
  返回 0
}
EOF

if node cnsh-compiler.js /tmp/test-audit.cnsh 2>&1 | grep -q "三色审计通过"; then
    echo "   ✅ 三色审计工作正常"
    ((TESTS_PASSED++))
else
    echo "   ❌ 三色审计未工作"
    ((TESTS_FAILED++))
fi

# 清理临时文件
rm -f /tmp/test-audit.cnsh /tmp/test-audit.c /tmp/test-audit
rm -f /tmp/cnsh_output.txt

# 测试总结
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "   📊 测试总结"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "   ✅ 通过：$TESTS_PASSED"
echo "   ❌ 失败：$TESTS_FAILED"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo "🎉 所有测试通过！"
    exit 0
else
    echo "⚠️  有测试失败，请检查"
    exit 1
fi
```

---

## 📄 补充6：性能基准测试

**文件名：** `benchmark.js`

**说明：** 测试编译器性能

```javascript
#!/usr/bin/env node
// CNSH编译器性能基准测试
// DNA追溯码：#ZHUGEXIN⚡️2025-12-31-CNSH语言-性能测试

const { CNSHCompiler } = require('./cnsh-compiler.js');
const fs = require('fs');

console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('   ⚡ CNSH编译器性能基准测试');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

// 生成测试代码
function generateTestCode(lines) {
  let code = '函数 主函数() 返回类型 整数 {\n';
  
  for (let i = 0; i < lines; i++) {
    code += `  整数 变量${i} = ${i}\n`;
  }
  
  code += '  返回 0\n}\n';
  return code;
}

// 性能测试
function benchmark(name, code) {
  const compiler = new CNSHCompiler();
  const tempFile = '/tmp/test-benchmark.cnsh';
  
  fs.writeFileSync(tempFile, code);
  
  const start = process.hrtime.bigint();
  const result = compiler.compile(code, tempFile);
  const end = process.hrtime.bigint();
  
  const duration = Number(end - start) / 1000000; // 转换为毫秒
  
  fs.unlinkSync(tempFile);
  if (result.success && fs.existsSync('/tmp/test-benchmark.c')) {
    fs.unlinkSync('/tmp/test-benchmark.c');
  }
  
  return {
    name,
    success: result.success,
    duration: duration.toFixed(2)
  };
}

// 运行测试
const tests = [
  { name: '小型代码（10行）', lines: 10 },
  { name: '中型代码（100行）', lines: 100 },
  { name: '大型代码（1000行）', lines: 1000 }
];

console.log('📊 测试结果：\n');

tests.forEach(test => {
  const code = generateTestCode(test.lines);
  const result = benchmark(test.name, code);
  
  console.log(`${result.name}：`);
  console.log(`   状态：${result.success ? '✅ 成功' : '❌ 失败'}`);
  console.log(`   耗时：${result.duration}ms`);
  console.log('');
});

console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('✨ 基准测试完成');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
```

---

## 📋 使用说明

### 给CodeBuddy的指令：

```bash
# 1. 创建优化模块文件
mkdir -p optimizations
cd optimizations

# 2. 创建各个优化模块
# error-recovery.js
# debug-info.js
# const-folding.js

# 3. 创建配置文件
# .gitignore

# 4. 创建测试脚本
chmod +x test-cnsh.sh
chmod +x benchmark.js

# 5. 运行测试
./test-cnsh.sh
node benchmark.js
```

### 集成到编译器的方式：

**在cnsh-compiler.js中添加：**

```javascript
// 顶部导入
const { ErrorRecovery } = require('./optimizations/error-recovery.js');
const { DebugInfoGenerator } = require('./optimizations/debug-info.js');
const { ConstantFolder } = require('./optimizations/const-folding.js');

// 在CNSHCompiler类中
class CNSHCompiler {
  constructor() {
    this.auditSystem = new ThreeColorAudit();
    this.errorRecovery = new ErrorRecovery();        // 新增
    this.debugInfo = new DebugInfoGenerator(true);   // 新增
    this.optimizer = new ConstantFolder();           // 新增
  }

  compile(sourceCode, sourcePath) {
    // ... 现有代码
    
    // 在语法分析后，代码生成前添加：
    console.log('🔧 阶段2.5：代码优化...');
    const optimizedAST = this.optimizer.optimize(ast);
    console.log(`   ${this.optimizer.getStats().message}\n`);
    
    // 使用优化后的AST生成代码
    const generator = new CCodeGenerator(optimizedAST);
    generator.debugInfo = this.debugInfo;  // 传入调试信息生成器
    
    // ... 继续
  }
}
```

---

## ✅ 优化效果

```yaml
错误恢复：
  - 一次编译发现多个错误
  - 提高开发效率

调试信息：
  - C代码包含CNSH行号注释
  - 方便定位问题

常量折叠：
  - 编译时计算常量表达式
  - 减少运行时开销
  - 示例：3 + 5 → 8

自动化测试：
  - 一键验证所有功能
  - 持续集成友好

性能测试：
  - 了解编译器性能
  - 发现性能瓶颈
```

---

**DNA追溯码：** `#ZHUGEXIN⚡️2025-12-31-CNSH语言-优化包-V1.0`

**老大，这6个补充优化，让编译器更专业了！** 💪
