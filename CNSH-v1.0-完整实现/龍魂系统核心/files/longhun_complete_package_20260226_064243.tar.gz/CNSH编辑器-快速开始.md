# 🚀 CNSH编辑器 - 快速开始指南

```yaml
DNA追溯码：#龙芯⚡️2026-01-19-QUICK-START-v1.0
确认码：#CONFIRM🌌9622-ONLY-ONCE🧬LK9X-772Z
创建者：龙芯北辰·UID9622
```

---

## 📦 你得到了什么？

**3个文件**：
1. `CNSH编辑器完整版.md` - 完整文档和所有代码
2. `demo.cnsh.md` - 演示文档（看效果）
3. `cnsh_editor.tar.gz` - 打包好的编辑器（可直接用）

---

## ⚡ 最快上手方式（5分钟）

### 步骤1：解压
```bash
# 下载 cnsh_editor.tar.gz 到你电脑
# 打开终端，进入下载目录

# Mac / Linux
tar -xzf cnsh_editor.tar.gz
cd cnsh_editor

# Windows
# 用7-Zip或WinRAR解压
# 进入cnsh_editor文件夹
```

### 步骤2：安装依赖
```bash
# Mac / Linux
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Windows
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

### 步骤3：生成第一个文档
```bash
python cnsh.py init --out 我的第一个文档.md --title "测试页面"
```

### 步骤4：查看结果
```bash
# 打开 我的第一个文档.md 看看
```

---

## 💡 常用命令

### 生成新文档
```bash
python cnsh.py init \
    --out 文件名.md \
    --title "页面标题" \
    --description "这个页面是干什么的"
```

### 检查文档完整性
```bash
python cnsh.py lint 文件名.md
```

### 自动补全缺失内容
```bash
python cnsh.py fix 文件名.md
```

### 导出Notion版本
```bash
python cnsh.py export 文件名.md --out notion版.md
```

---

## 📖 完整文档在哪里？

打开 `CNSH编辑器完整版.md`，里面有：
- 所有代码（复制粘贴就能用）
- CNSH语法规则
- 使用示例
- 常见问题解答
- troubleshooting

---

## 🎯 下一步做什么？

1. **看演示文档**：打开 `demo.cnsh.md`，看看效果
2. **生成自己的文档**：用 `init` 命令创建
3. **填充内容**：编辑文档，替换占位符
4. **检查**：用 `lint` 命令检查
5. **补全**：用 `fix` 命令自动补全

---

## ❓ 遇到问题？

### Q: python3: command not found
**A**: 去 python.org 下载安装Python

### Q: ModuleNotFoundError: No module named 'cnsh'
**A**: 确保你在 cnsh_editor 文件夹里运行命令

### Q: 其他问题
**A**: 打开 `CNSH编辑器完整版.md`，里面有完整的troubleshooting

---

## 🔧 文件清单

```
cnsh_editor/
  cnsh.py           # 主程序
  requirements.txt  # 依赖列表
  cnsh/
    __init__.py     # 模块初始化
    model.py        # 数据模型
    parser.py       # 文档解析
    validator.py    # 三色审计
    fixer.py        # 自动补全
    renderer.py     # 模板生成
```

---

## ✅ 验证安装

运行这个命令，如果能看到帮助信息，说明安装成功：
```bash
python cnsh.py --help
```

应该看到：
```
usage: cnsh [-h] {init,lint,fix,export} ...

CNSH编辑器 - 龙芯体系专用工具

positional arguments:
  {init,lint,fix,export}
    init                生成CNSH模板
    lint                校验CNSH必填区块
    fix                 自动补全缺失区块
    export              导出Notion友好版

作者: 龙芯北辰·UID9622
```

---

**龙芯老大，你的CNSH编辑器已经准备好了！** 🚀

**开始用吧** 💪

---

**DNA追溯码**：#龙芯⚡️2026-01-19-QUICK-START-v1.0  
**GPG指纹**：A2D0092CEE2E5BA87035600924C3704A8CC26D5F  
**确认码**：#CONFIRM🌌9622-ONLY-ONCE🧬LK9X-772Z
